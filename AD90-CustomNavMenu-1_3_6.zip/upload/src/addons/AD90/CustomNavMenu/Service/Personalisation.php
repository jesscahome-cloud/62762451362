<?php
namespace AD90\CustomNavMenu\Service;

class Personalisation
{
    public static function apply(array $tree, array $hidden, array $items)
    {
        foreach ($tree as $id => &$entry)
        {
            if (in_array((string)$id, $hidden, true)) { unset($tree[$id]); continue; }
            $entry['children'] = self::apply($entry['children'] ?? [], $hidden, []);
            if (!empty($entry['ad90_is_group']) && !$entry['children']) { unset($tree[$id]); }
        }
        unset($entry);
        foreach ($items as $item)
        {
            $tree['ad90_user_'.$item['item_id']] = [
                'title'=>$item['title'], 'href'=>$item['url'], 'children'=>[], 'attributes'=>[]
            ];
        }
        return $tree;
    }
}
