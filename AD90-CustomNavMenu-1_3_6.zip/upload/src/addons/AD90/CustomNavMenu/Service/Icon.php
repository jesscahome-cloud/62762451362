<?php
namespace AD90\CustomNavMenu\Service;

class Icon
{
    // SVG is deliberately restricted to static vector geometry. No URLs, CSS or references.
    public static function sanitizeSvg($svg)
    {
        if (strlen($svg) > 65536 || preg_match('/<!DOCTYPE|<!ENTITY/i', $svg))
        {
            throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_svg_size'));
        }
        $doc = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try { $ok = $doc->loadXML($svg, LIBXML_NONET); }
        finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
        if (!$ok || !$doc->documentElement || $doc->documentElement->localName !== 'svg')
        {
            throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_svg_invalid'));
        }
        $tags = ['svg', 'g', 'path', 'circle', 'ellipse', 'rect', 'line', 'polyline', 'polygon', 'title', 'desc'];
        $attrs = ['viewBox', 'width', 'height', 'd', 'x', 'y', 'x1', 'x2', 'y1', 'y2', 'cx', 'cy', 'r', 'rx', 'ry', 'points', 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'fill-rule', 'clip-rule', 'opacity', 'fill-opacity', 'stroke-opacity', 'transform'];
        foreach ($doc->getElementsByTagName('*') as $node)
        {
            if (!in_array($node->localName, $tags, true) || ($node->namespaceURI && $node->namespaceURI !== 'http://www.w3.org/2000/svg'))
            {
                throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_svg_element'));
            }
            foreach ($node->attributes as $attr)
            {
                if ($attr->nodeName === 'xmlns' && $attr->value === 'http://www.w3.org/2000/svg') { continue; }
                if (!in_array($attr->nodeName, $attrs, true) || preg_match('/url\s*\(|[<>]|[\\\\]/i', $attr->value))
                {
                    throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_svg_attribute'));
                }
            }
        }
        return $doc->saveXML($doc->documentElement);
    }

    public static function isFillOnlySvg($svg)
    {
        $doc = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try { $ok = $doc->loadXML($svg, LIBXML_NONET); }
        finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
        if (!$ok) { return false; }
        foreach ($doc->getElementsByTagName('*') as $node)
        {
            $stroke = strtolower(trim($node->getAttribute('stroke')));
            if (strtolower(trim($node->getAttribute('fill'))) === 'none'
                || ($stroke !== '' && $stroke !== 'none')) { return false; }
        }
        return true;
    }

    public static function delete($id)
    {
        $db = \XF::db();
        $path = $db->fetchOne('SELECT file_path FROM xf_ad90_nav_icon WHERE icon_id = ?', $id);
        if ($path && \XF::fs()->has($path)) { \XF::fs()->delete($path); }
        $db->delete('xf_ad90_nav_icon', 'icon_id = ?', $id);
    }

    public static function fromInput($upload, $svg)
    {
        if ($upload)
        {
            // XF 2.3 may convert PNG to WebP inside isValid(), before checking extensions.
            // Icons are validated and re-encoded as PNG below; keep their input format here.
            $upload->setImageOptimize(false);
            $upload->setAllowedExtensions(['png', 'svg']);
            $upload->setMaxFileSize(262144);
            $errors = [];
            if (!$upload->isValid($errors)) { throw new \InvalidArgumentException(implode(' ', $errors)); }
            $data = file_get_contents($upload->getTempFile());
            if (strtolower($upload->getExtension()) === 'svg') { $svg = $data; }
            else
            {
                $info = @getimagesizefromstring($data);
                if (!$info || $info[2] !== IMAGETYPE_PNG || $info[0] > 512 || $info[1] > 512)
                { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_png_size')); }
                $image = @imagecreatefromstring($data);
                if (!$image) { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_png_invalid')); }
                imagesavealpha($image, true);
                ob_start(); imagepng($image); $data = ob_get_clean(); imagedestroy($image);
                return ['mime_type' => 'image/png', 'icon_data' => $data, 'file_path'=>'pending.png'];
            }
        }
        return trim($svg) !== '' ? ['mime_type' => 'image/svg+xml', 'icon_data' => self::sanitizeSvg($svg), 'file_path'=>$upload ? 'pending.svg' : ''] : null;
    }
}
