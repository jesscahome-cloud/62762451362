<?php
namespace AD90\CustomNavMenu\Service;

class Counters extends \XF\Service\AbstractService
{
    protected $values = [];
    public function resolve($source, array $entry)
    {
        $visitor = \XF::visitor();
        switch ($source)
        {
            case 'none': return 0;
            case 'alerts': return $visitor->user_id ? $visitor->alerts_unviewed : 0;
            case 'conversations': return $visitor->user_id ? $visitor->conversations_unread : 0;
            case 'threads':
                if (isset($this->values['threads'])) { return $this->values['threads']; }
                if (!$visitor->user_id) { return 0; }
                // Count only forums this visitor can view, including node permissions.
                $forums = $this->app->repository('XF:Forum')->getViewableForums();
                if (!$forums->count()) { return 0; }
                $all = []; $own = [];
                foreach ($forums as $forum)
                {
                    if (!$visitor->hasNodePermission($forum->node_id, 'view')
                        || !$visitor->hasNodePermission($forum->node_id, 'viewContent')) { continue; }
                    if ($visitor->hasNodePermission($forum->node_id, 'viewOthers')) { $all[] = $forum->node_id; }
                    else { $own[] = $forum->node_id; }
                }
                $db = $this->db();
                $conditions = [];
                if ($all) { $conditions[] = 't.node_id IN ('.$db->quote($all).')'; }
                if ($own) { $conditions[] = '(t.node_id IN ('.$db->quote($own).') AND t.user_id = '.(int)$visitor->user_id.')'; }
                if (!$conditions) { return $this->values['threads'] = 0; }
                return $this->values['threads'] = (int)$db->fetchOne(
                    'SELECT COUNT(*) FROM xf_thread AS t
                    LEFT JOIN xf_thread_read AS tr ON tr.thread_id = t.thread_id AND tr.user_id = ?
                    LEFT JOIN xf_forum_read AS fr ON fr.node_id = t.node_id AND fr.user_id = ?
                    WHERE ('.implode(' OR ', $conditions).') AND t.discussion_state = \'visible\'
                    AND t.discussion_type <> \'redirect\'
                    AND t.last_post_date > ?
                    AND t.last_post_date > COALESCE(tr.thread_read_date, 0)
                    AND t.last_post_date > COALESCE(fr.forum_read_date, 0)',
                    [$visitor->user_id, $visitor->user_id, $this->app->repository('XF:Thread')->getReadMarkingCutOff()]
                );
            case 'native': return max(0, (int)($entry['counter'] ?? 0));
            default:
                if (!array_key_exists($source, $this->values))
                {
                    $count = 0;
                    $this->app->fire('ad90_nav_counter', [$visitor, $source, &$count], $source);
                    $this->values[$source] = max(0, (int)$count);
                }
                return $this->values[$source];
        }
    }

    public static function aggregate(array $tree, array $sources, callable $resolve, $parent = '')
    {
        foreach ($tree as $id => &$entry)
        {
            $entry['children'] = self::aggregate($entry['children'] ?? [], $sources, $resolve, (string)$id);
            $entry['ad90_parent'] = $parent;
            $entry['ad90_counter_source'] = $sources[$id] ?? 'native';
            $source = $sources[$id] ?? 'native';
            $own = max(0, (int)$resolve($source, $entry));
            // A branch displays the sum of its visible descendants. Do not add
            // its existing aggregate again, which would double-count children.
            $entry['counter'] = $entry['children']
                ? array_sum(array_column($entry['children'], 'counter')) : $own;
        }
        unset($entry);
        return $tree;
    }
}
