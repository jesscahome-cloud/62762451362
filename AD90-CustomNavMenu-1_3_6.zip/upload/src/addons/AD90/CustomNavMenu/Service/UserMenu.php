<?php
namespace AD90\CustomNavMenu\Service;

class UserMenu extends \XF\Service\AbstractService
{
    public function save(\XF\Entity\User $user, array $hidden, array $edits, array $delete, array $new)
    {
        if (!$user->user_id) { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_login_required')); }
        $db = $this->db();
        $db->beginTransaction();
        try
        {
            // Serialize updates and the 50-item limit for this owner.
            $db->fetchOne('SELECT user_id FROM xf_user WHERE user_id = ? FOR UPDATE', $user->user_id);
            $existing = $db->fetchAllKeyed('SELECT * FROM xf_custom_nav_user_item WHERE user_id = ?', 'item_id', $user->user_id);
            foreach ($delete as $id)
            {
                if (isset($existing[$id]))
                {
                    $db->delete('xf_custom_nav_user_item', 'item_id = ? AND user_id = ?', [$id, $user->user_id]);
                    unset($existing[$id]);
                }
            }
            foreach ($edits as $id => $row)
            {
                if (!isset($existing[$id])) { continue; }
                if (!is_array($row)) { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_link_invalid')); }
                $db->update('xf_custom_nav_user_item', $this->validate($row), 'item_id = ? AND user_id = ?', [$id, $user->user_id]);
            }
            if (trim($new['title'] ?? '') !== '' || trim($new['url'] ?? '') !== '')
            {
                if (count($existing) >= 50) { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_link_limit')); }
                $db->insert('xf_custom_nav_user_item', ['user_id'=>$user->user_id] + $this->validate($new));
            }
            $nativeIds = $db->fetchAllColumn('SELECT navigation_id FROM xf_navigation');
            $hidden = array_values(array_intersect(array_unique($hidden), $nativeIds));
            $db->insert('xf_custom_nav_user_preference', ['user_id'=>$user->user_id, 'hidden_items'=>json_encode($hidden)], false, 'hidden_items = VALUES(hidden_items)');
            $db->commit();
        }
        catch (\Throwable $e) { $db->rollback(); throw $e; }
    }

    protected function validate(array $row)
    {
        foreach (['title','url','display_order'] as $key)
        {
            if (isset($row[$key]) && !is_scalar($row[$key])) { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_link_invalid')); }
        }
        $title = trim($row['title'] ?? '');
        $url = trim($row['url'] ?? '');
        if ($title === '' || $url === '' || mb_strlen($title) > 100 || strlen($url) > 2048 || !MenuTree::validUrl($url))
        { throw new \InvalidArgumentException((string)\XF::phrase('ad90_nav_link_title_url')); }
        return ['title'=>$title, 'url'=>$url, 'display_order'=>max(0, (int)($row['display_order'] ?? 100))];
    }
}
