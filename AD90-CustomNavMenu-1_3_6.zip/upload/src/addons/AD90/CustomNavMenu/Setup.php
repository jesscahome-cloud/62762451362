<?php
namespace AD90\CustomNavMenu;

use XF\Db\Schema\Create;

class Setup extends \XF\AddOn\AbstractSetup
{
    public function install(array $stepParams = [])
    {
        $this->schemaManager()->createTable('xf_ad90_nav_item', function (Create $table)
        {
            $table->addColumn('item_id', 'int')->autoIncrement();
            $table->addColumn('native_id', 'varbinary', 50)->setDefault('');
            $table->addColumn('parent_key', 'varbinary', 60)->setDefault('');
            $table->addColumn('title', 'varchar', 100)->setDefault('');
            $table->addColumn('url', 'varchar', 2048)->setDefault('');
            $table->addColumn('display_order', 'int')->setDefault(100);
            $table->addColumn('enabled', 'tinyint')->setDefault(1);
            $table->addColumn('target_blank', 'tinyint')->setDefault(0);
            $table->addColumn('permission_group', 'varbinary', 25)->setDefault('');
            $table->addColumn('permission_id', 'varbinary', 25)->setDefault('');
            $table->addColumn('icon_id', 'int')->setDefault(0);
            $table->addKey('parent_key');
        });
        $this->schemaManager()->createTable('xf_ad90_nav_icon', function (Create $table)
        {
            $table->addColumn('icon_id', 'int')->autoIncrement();
            $table->addColumn('mime_type', 'varchar', 30);
            $table->addColumn('icon_data', 'mediumblob');
            $table->addColumn('file_path', 'varchar', 250)->setDefault('');
        });
        $this->installPersonalisation();
    }

    public function upgrade(array $stepParams = [])
    {
        $this->installPersonalisation();
        \XF::app()->service('AD90\CustomNavMenu:NativeNavigation')->migrate();
    }

    protected function installPersonalisation()
    {
        $sm = $this->schemaManager();
        if (!$sm->columnExists('xf_ad90_nav_item', 'counter_source'))
        {
            $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) {
                $table->addColumn('counter_source', 'varchar', 50)->setDefault('native');
            });
        }
        if (!$sm->columnExists('xf_ad90_nav_item', 'override_parent'))
        {
            $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) {
                $table->addColumn('override_parent', 'tinyint')->setDefault(0);
            });
        }
        if (!$sm->columnExists('xf_ad90_nav_item', 'use_item_permission'))
        {
            $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) {
                $table->addColumn('use_item_permission', 'tinyint')->setDefault(0);
            });
        }
        if (!$sm->tableExists('xf_custom_nav_user_item'))
        {
            $sm->createTable('xf_custom_nav_user_item', function (Create $table) {
                $table->addColumn('item_id', 'int')->autoIncrement();
                $table->addColumn('user_id', 'int');
                $table->addColumn('title', 'varchar', 100);
                $table->addColumn('url', 'varchar', 2048);
                $table->addColumn('display_order', 'int')->setDefault(100);
                $table->addKey('user_id');
            });
        }
        if (!$sm->tableExists('xf_custom_nav_user_preference'))
        {
            $sm->createTable('xf_custom_nav_user_preference', function (Create $table) {
                $table->addColumn('user_id', 'int')->primaryKey();
                $table->addColumn('hidden_items', 'mediumblob');
            });
        }
        if (!$sm->tableExists('xf_ad90_nav_account_tile'))
        {
            $sm->createTable('xf_ad90_nav_account_tile', function (Create $table) {
                $table->addColumn('tile_id', 'int')->autoIncrement();
                $table->addColumn('title', 'varchar', 100)->setDefault('');
                $table->addColumn('url', 'varchar', 2048)->setDefault('');
                $table->addColumn('link_type', 'varchar', 25)->setDefault('custom');
                $table->addColumn('icon_id', 'int')->setDefault(0);
                $table->addColumn('display_order', 'int')->setDefault(100);
                $table->addColumn('enabled', 'tinyint')->setDefault(1);
                $table->addColumn('permission_group', 'varbinary', 25)->setDefault('');
                $table->addColumn('permission_id', 'varbinary', 25)->setDefault('');
            });
            foreach (['my_threads','bookmarks','navigation','account'] as $order=>$type)
            {
                \XF::db()->insert('xf_ad90_nav_account_tile', ['link_type'=>$type, 'display_order'=>($order + 1) * 100]);
            }
        }
        foreach (['description'=>500, 'section_title'=>500, 'menu_class'=>100] as $column=>$length)
        {
            if (!$sm->columnExists('xf_ad90_nav_item', $column))
            {
                $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) use ($column, $length) {
                    $table->addColumn($column, 'varchar', $length)->setDefault('');
                });
            }
        }
        $sectionDefinition = null;
        if ($sm->columnExists('xf_ad90_nav_item', 'section_title', $sectionDefinition)
            && $sectionDefinition['Type'] === 'varchar(100)')
        {
            $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) {
                $table->changeColumn('section_title', 'varchar', 500);
            });
        }
        if (!$sm->columnExists('xf_ad90_nav_item', 'native_managed'))
        {
            $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) {
                $table->addColumn('native_managed', 'tinyint')->setDefault(0);
            });
        }
        if (!$sm->columnExists('xf_ad90_nav_item', 'is_group'))
        {
            $sm->alterTable('xf_ad90_nav_item', function (\XF\Db\Schema\Alter $table) {
                $table->addColumn('is_group', 'tinyint')->setDefault(0);
            });
        }
        // Earlier releases could leave a permission phrase after deleting its item.
        foreach (\XF::finder('XF:Phrase')->where('title', 'LIKE', 'permission.ad90Nav_item%')->fetch() as $phrase)
        {
            if (preg_match('/^permission\.ad90Nav_(item[0-9]+)$/D', $phrase->title, $match)
                && !\XF::em()->find('XF:Permission', ['ad90Nav', $match[1]]))
            {
                $phrase->delete();
            }
        }
        \XF::app()->registry()->delete('ad90NavItems');
    }

    public function uninstall(array $stepParams = [])
    {
        foreach (\XF::db()->fetchAllColumn('SELECT icon_id FROM xf_ad90_nav_icon') as $id) { Service\Icon::delete($id); }
        foreach (\XF::em()->getFinder('XF:Permission')->where('permission_group_id', 'ad90Nav')->fetch() as $permission) { $permission->delete(); }
        $this->schemaManager()->dropTable('xf_custom_nav_user_item');
        $this->schemaManager()->dropTable('xf_custom_nav_user_preference');
        $this->schemaManager()->dropTable('xf_ad90_nav_account_tile');
        $this->schemaManager()->dropTable('xf_ad90_nav_item');
        $this->schemaManager()->dropTable('xf_ad90_nav_icon');
        \XF::app()->registry()->delete('ad90NavItems');
        \XF::app()->registry()->delete('ad90NavRuntime');
    }
}
