<?php
namespace AD90\CustomNavMenu\Repository;

class Navigation extends \XF\Mvc\Entity\Repository
{
    protected $nativeOrders;

    public function getAdminNodes()
    {
        $nodes = [];
        foreach ($this->getNativeItems() as $id=>$row)
        {
            $nodes[$id] = ['id'=>$id, 'title'=>$row['title'], 'parent_id'=>$row['parent_key'],
                'display_order'=>$row['display_order'], 'enabled'=>true, 'entity'=>null, 'stale'=>false];
        }
        foreach ($this->finder('AD90\CustomNavMenu:MenuItem')->fetch() as $item)
        {
            $id = $item->native_id ?: 'ad90_'.$item->item_id;
            $original = $nodes[$id] ?? null;
            $nodes[$id] = ['id'=>$id, 'title'=>$item->native_id ? ($original['title'] ?? $item->native_id) : $item->title,
                'parent_id'=>!$item->native_id || $item->override_parent ? $item->parent_key : ($original['parent_id'] ?? ''),
                'display_order'=>$item->display_order, 'enabled'=>$item->enabled, 'entity'=>$item,
                'stale'=>(bool)$item->native_id && !$original];
        }
        foreach ($nodes as &$node)
        {
            if ($node['parent_id'] !== '' && !isset($nodes[$node['parent_id']])) { $node['parent_id'] = ''; }
        }
        unset($node);
        uasort($nodes, function ($a, $b) { return $a['display_order'] <=> $b['display_order']; });
        return $nodes;
    }

    public function getNativeOrders()
    {
        if ($this->nativeOrders === null)
        {
            $this->nativeOrders = $this->db()->fetchPairs('SELECT navigation_id, display_order FROM xf_navigation');
        }
        return $this->nativeOrders;
    }

    public function getUserSettings($userId)
    {
        $rows = $this->db()->fetchAll('SELECT p.hidden_items, i.* FROM xf_user AS u
            LEFT JOIN xf_custom_nav_user_preference AS p ON p.user_id = u.user_id
            LEFT JOIN xf_custom_nav_user_item AS i ON i.user_id = u.user_id
            WHERE u.user_id = ? ORDER BY i.display_order, i.item_id', $userId);
        return [json_decode($rows[0]['hidden_items'] ?? '[]', true) ?: [],
            array_values(array_filter($rows, function ($row) { return $row['item_id'] !== null; }))];
    }

    public function getRows()
    {
        $rows = \XF::app()->registry()->get('ad90NavItems');
        if ($rows === null)
        {
            $rows = $this->db()->fetchAll('SELECT * FROM xf_ad90_nav_item ORDER BY display_order, item_id');
            \XF::app()->registry()->set('ad90NavItems', $rows);
        }
        return $rows;
    }
    public function getNativeItems()
    {
        $items = [];
        $active = $this->db()->fetchAllColumn('SELECT addon_id FROM xf_addon WHERE active = 1');
        foreach ($this->finder('XF:Navigation')->order('display_order')->fetch() as $nav)
        {
            if ($nav->addon_id !== '' && $nav->addon_id !== 'XF' && !in_array($nav->addon_id, $active, true)) { continue; }
            $items[$nav->navigation_id] = ['id'=>$nav->navigation_id, 'title'=>(string)$nav->title,
                'parent_key'=>$nav->parent_navigation_id, 'display_order'=>$nav->display_order];
        }
        foreach (\XF::app()->registry()->get('ad90NavRuntime') ?: [] as $id=>$row)
        {
            if (!isset($items[$id])) { $items[$id] = $row; }
        }
        return $items;
    }

    public function refreshCatalog()
    {
        // Dynamic entries are rediscovered on public pages in the appropriate visitor context.
        // Do not interpret absence from one visitor's tree as deletion for everyone.
        \XF::app()->registry()->delete('ad90NavRuntime');
        $this->nativeOrders = null;
    }

    public function rememberRuntime(array $tree)
    {
        $known = $this->getNativeOrders();
        $runtime = \XF::app()->registry()->get('ad90NavRuntime') ?: [];
        $changed = false;
        $walk = function ($entries, $parent = '') use (&$walk, &$runtime, &$changed, $known)
        {
            $order = 0;
            foreach ($entries as $id=>$entry)
            {
                $order += 100;
                if (!isset($known[$id]) && !isset($runtime[$id]) && count($runtime) < 1000 && strlen($id) <= 50)
                {
                    // Runtime titles/URLs may contain visitor data. Store the stable ID only.
                    $runtime[$id] = ['id'=>$id, 'title'=>$id, 'parent_key'=>$parent, 'display_order'=>$order];
                    $changed = true;
                }
                $walk($entry['children'] ?? [], $id);
            }
        };
        $walk($tree);
        if ($changed) { \XF::app()->registry()->set('ad90NavRuntime', $runtime); }
    }

    public function getParentMap()
    {
        $parents = [];
        foreach ($this->getNativeItems() as $id=>$row) { $parents[$id] = $row['parent_key']; }
        foreach ($this->getRows() as $row)
        {
            if (!$row['native_id']) { $parents['ad90_'.$row['item_id']] = $row['parent_key']; }
            elseif (isset($parents[$row['native_id']]) && !empty($row['override_parent'])) { $parents[$row['native_id']] = $row['parent_key']; }
        }
        return $parents;
    }
    public function getIconUris()
    {
        $result = [];
        foreach ($this->db()->fetchAll('SELECT * FROM xf_ad90_nav_icon') as $icon)
        {
            $data = $icon['icon_data'];
            if ($icon['file_path'])
            {
                if (!\XF::fs()->has($icon['file_path'])) { continue; }
                $data = \XF::fs()->read($icon['file_path']);
            }
            $result[$icon['icon_id']] = ['svg'=>$icon['mime_type'] === 'image/svg+xml' ? $data : '',
                'only_fill'=>$icon['mime_type'] === 'image/svg+xml' && \AD90\CustomNavMenu\Service\Icon::isFillOnlySvg($data),
                'uri'=>$icon['mime_type'] === 'image/png' ? 'data:image/png;base64,' . base64_encode($data) : ''];
        }
        return $result;
    }
}
