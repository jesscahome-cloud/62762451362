<?php
namespace AD90\CustomNavMenu\XF\Pub\Controller;

class Account extends XFCP_Account
{
    public function actionCustomNavigation()
    {
        if (!\XF::options()->ad90NavEnabled) { return $this->noPermission(); }
        $visitor = \XF::visitor();
        $db = $this->app()->db();
        if ($this->isPost())
        {
            try
            {
                $this->service('AD90\CustomNavMenu:UserMenu')->save(
                    $visitor,
                    $this->filter('hidden', 'array-str'),
                    $this->filter('items', 'array'),
                    $this->filter('delete', 'array-uint'),
                    $this->filter(['title'=>'str', 'url'=>'str', 'display_order'=>'uint'])
                );
            }
            catch (\InvalidArgumentException $e) { return $this->error($e->getMessage()); }
            return $this->redirect($this->buildLink('account/custom-navigation'));
        }
        $hidden = json_decode($db->fetchOne('SELECT hidden_items FROM xf_custom_nav_user_preference WHERE user_id = ?', $visitor->user_id) ?: '[]', true) ?: [];
        $view = $this->view('AD90\CustomNavMenu:Account', 'ad90_nav_preferences_menu', [
            'nativeItems'=>$this->finder('XF:Navigation')->order('display_order')->fetch(),
            'hiddenItems'=>$hidden,
            'items'=>$db->fetchAll('SELECT * FROM xf_custom_nav_user_item WHERE user_id = ? ORDER BY display_order, item_id', $visitor->user_id)
        ]);
        return $this->addAccountWrapperParams($view, 'customNavigation');
    }
}
