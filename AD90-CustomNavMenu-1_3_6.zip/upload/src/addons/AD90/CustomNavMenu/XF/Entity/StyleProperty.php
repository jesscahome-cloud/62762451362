<?php
namespace AD90\CustomNavMenu\XF\Entity;

class StyleProperty extends XFCP_StyleProperty
{
    protected function validateValuePropertyValue($value)
    {
        if ($this->group_name === 'ad90Nav' && $this->property_type === 'value' && $this->value_type === 'color')
        {
            $normalize = static function ($color) {
                return is_string($color) ? preg_replace('/;\s*$/', '', trim($color)) : $color;
            };
            $value = is_array($value) ? array_map($normalize, $value) : $normalize($value);
        }
        return parent::validateValuePropertyValue($value);
    }
}
