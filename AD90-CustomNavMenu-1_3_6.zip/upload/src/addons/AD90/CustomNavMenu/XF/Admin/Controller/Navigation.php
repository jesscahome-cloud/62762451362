<?php
namespace AD90\CustomNavMenu\XF\Admin\Controller;

use XF\Entity\Navigation as NavigationEntity;
use XF\Mvc\FormAction;
use XF\Mvc\ParameterBag;
use AD90\CustomNavMenu\Service\Icon;

class Navigation extends XFCP_Navigation
{
    protected function navigationAddEdit(NavigationEntity $navigation)
    {
        $reply = parent::navigationAddEdit($navigation);
        $reply->setParams($this->service('AD90\CustomNavMenu:NativeNavigation')->getEditParams($navigation->navigation_id));
        return $reply;
    }

    public function actionIndex()
    {
        $reply = parent::actionIndex();
        $native = $this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders();
        $runtime = array_filter($this->repository('AD90\CustomNavMenu:Navigation')->getAdminNodes(), function ($node) use ($native)
        { return !isset($native[$node['id']]); });
        $reply->setParam('ad90RuntimeItems', $runtime);
        return $reply;
    }

    protected function navigationSaveProcess(NavigationEntity $navigation)
    {
        $form = parent::navigationSaveProcess($navigation);
        // Other extensions may save native entries without submitting our form section.
        if (!$this->filter('ad90_present', 'bool')) { return $form; }
        $item = $this->service('AD90\CustomNavMenu:NativeNavigation')->getItem($navigation->navigation_id);
        $input = $this->filter(['ad90'=>[
            'description'=>'str', 'section_title'=>'str', 'menu_class'=>'str', 'use_menu_class'=>'bool',
            'permission_group'=>'str', 'permission_id'=>'str', 'use_item_permission'=>'bool',
            'target_blank'=>'bool', 'is_group'=>'bool', 'runtime_parent'=>'str', 'counter_source'=>'str', 'counter_provider'=>'str'
        ]])['ad90'];
        if (!$input['use_menu_class']) { $input['menu_class'] = ''; }
        unset($input['use_menu_class']);
        if ($input['counter_source'] === 'custom') { $input['counter_source'] = $input['counter_provider']; }
        unset($input['counter_provider']);
        $runtimeParent = $input['runtime_parent']; unset($input['runtime_parent']);
        $nativeIds = $this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders();
        $runtimeItems = $this->repository('AD90\CustomNavMenu:Navigation')->getNativeItems();
        $form->validate(function (FormAction $form) use ($navigation, $item, $input, $runtimeParent, $nativeIds, $runtimeItems)
        {
            if (!preg_match('/^[a-zA-Z0-9_]{1,50}$/D', $input['counter_source']))
            { $form->logError(\XF::phrase('ad90_nav_counter_id_required')); }
            if ($runtimeParent !== '' && (isset($nativeIds[$runtimeParent]) || (!isset($runtimeItems[$runtimeParent]) && $runtimeParent !== $item->parent_key)))
            { $form->logError(\XF::phrase('ad90_nav_parent_invalid')); }
            if ($runtimeParent !== '' && (!$item->override_parent || $runtimeParent !== $item->parent_key))
            {
                $parents = $this->repository('AD90\CustomNavMenu:Navigation')->getParentMap();
                $parents[$navigation->navigation_id] = $runtimeParent;
                try { \AD90\CustomNavMenu\Service\MenuTree::validateParents($parents, PHP_INT_MAX, [$navigation->navigation_id]); }
                catch (\InvalidArgumentException $e) { $form->logError($e->getMessage()); }
            }
            if ($input['is_group'] && $navigation->parent_navigation_id === '' && $runtimeParent === '')
            { $form->logError(\XF::phrase('ad90_nav_group_parent_required')); }
            $item->bulkSet($input);
            $item->override_parent = $runtimeParent !== '';
            $item->parent_key = $runtimeParent;
            $item->native_id = $navigation->navigation_id;
            $item->native_managed = true;
            // The native entity is created/renamed during apply; validate supplemental fields now.
            $item->setOption('skip_native_validation', true);
            $item->setOption('skip_parent_validation', true);
            $item->preSave();
            $form->logErrors($item->getErrors());
        });
        $icon = null;
        $form->validate(function (FormAction $form) use (&$icon)
        {
            try { $icon = Icon::fromInput($this->request->getFile('ad90_icon', false, false), $this->filter('ad90_svg', 'str')); }
            catch (\InvalidArgumentException $e) { $form->logError($e->getMessage()); }
        });
        $form->applyInTransaction($this->app()->db());
        $oldIcon = 0;
        $form->apply(function () use ($navigation, $item, &$icon, &$oldIcon)
        {
            $oldIcon = $item->icon_id;
            $newPath = '';
            try
            {
                if ($icon)
                {
                    if ($icon['file_path'])
                    {
                        $newPath = 'internal-data://ad90/custom_nav_menu/icons/'.bin2hex(random_bytes(16)).'.'.pathinfo($icon['file_path'], PATHINFO_EXTENSION);
                        \XF::fs()->write($newPath, $icon['icon_data']);
                        $icon['file_path'] = $newPath; $icon['icon_data'] = '';
                    }
                    $this->app()->db()->insert('xf_ad90_nav_icon', $icon);
                    $item->set('icon_id', $this->app()->db()->lastInsertId(), ['forceSet'=>true]);
                }
                elseif ($this->filter('ad90_remove_icon', 'bool')) { $item->set('icon_id', 0, ['forceSet'=>true]); }
                $item->save();
            }
            catch (\Throwable $e)
            {
                if ($newPath && \XF::fs()->has($newPath)) { \XF::fs()->delete($newPath); }
                throw $e;
            }
        });
        $form->complete(function () use (&$oldIcon, $item)
        {
            if ($oldIcon && $oldIcon != $item->icon_id) { Icon::delete($oldIcon); }
        });
        return $form;
    }

    public function actionAd90Runtime(ParameterBag $params)
    {
        $id = (string)$params->navigation_id;
        if (isset($this->repository('AD90\CustomNavMenu:Navigation')->getNativeOrders()[$id]))
        { return $this->redirect($this->buildLink('navigation/edit', ['navigation_id'=>$id])); }
        return $this->rerouteController('AD90\CustomNavMenu:MenuItem', 'Runtime', ['native_id'=>$id]);
    }
}
