<?php
namespace AD90\CustomNavMenu;

class Listener
{
    public static function navigationSetup(\XF\Pub\App $app, array &$flat, array &$tree)
    {
        if (!$app->options()->ad90NavEnabled) { return; }
        $repo = $app->repository('AD90\CustomNavMenu:Navigation');
        $repo->rememberRuntime($tree);
        $icons = $repo->getIconUris();
        $visitor = \XF::visitor();
        $tree = Service\MenuTree::apply($tree, $repo->getRows(), function ($row) use ($visitor)
        { return (!$row['use_item_permission'] || $visitor->hasPermission('ad90Nav', 'item'.$row['item_id'])) && (!$row['permission_id'] || $visitor->hasPermission($row['permission_group'], $row['permission_id'])); },
        function ($id) use ($icons) { return $icons[$id] ?? ''; },
        $repo->getNativeOrders());
        $sources = [];
        foreach ($repo->getRows() as $row) { $sources[$row['native_id'] ?: 'ad90_'.$row['item_id']] = $row['counter_source']; }
        if ($visitor->user_id)
        {
            [$hidden, $items] = $repo->getUserSettings($visitor->user_id);
            $tree = Service\Personalisation::apply($tree, $hidden, $items);
        }
        $counters = $app->service('AD90\CustomNavMenu:Counters');
        $tree = Service\Counters::aggregate($tree, $sources, function ($source, $entry) use ($counters) { return $counters->resolve($source, $entry); });
        $flat = [];
        $flatten = function (array &$entries) use (&$flatten, &$flat)
        {
            foreach ($entries as $id => &$entry)
            {
                $flat[$id] =& $entry;
                if (!empty($entry['children'])) { $flatten($entry['children']); }
            }
        };
        $flatten($tree);
    }
}
