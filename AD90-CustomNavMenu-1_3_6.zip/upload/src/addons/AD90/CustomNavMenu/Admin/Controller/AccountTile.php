<?php
namespace AD90\CustomNavMenu\Admin\Controller;

use XF\Mvc\ParameterBag;
use AD90\CustomNavMenu\Service\Icon;

class AccountTile extends \XF\Admin\Controller\AbstractController
{
    protected function preDispatchController($action, ParameterBag $params)
    { $this->assertAdminPermission('navigation'); }

    public function actionIndex()
    {
        return $this->view('AD90\CustomNavMenu:AccountTile\List', 'ad90_nav_tile_list', [
            'tiles'=>$this->finder('AD90\CustomNavMenu:AccountTile')->order(['display_order','tile_id'])->fetch()
        ]);
    }
    public function actionAdd()
    { return $this->edit($this->em()->create('AD90\CustomNavMenu:AccountTile')); }
    public function actionEdit(ParameterBag $params)
    { return $this->edit($this->assertRecordExists('AD90\CustomNavMenu:AccountTile', $params->tile_id)); }
    protected function edit($tile)
    { return $this->view('AD90\CustomNavMenu:AccountTile\Edit', 'ad90_nav_tile_edit', ['tile'=>$tile]); }

    public function actionSave(ParameterBag $params)
    {
        $this->assertPostOnly();
        $tile = $params->tile_id ? $this->assertRecordExists('AD90\CustomNavMenu:AccountTile', $params->tile_id)
            : $this->em()->create('AD90\CustomNavMenu:AccountTile');
        $tile->bulkSet($this->filter(['title'=>'str','url'=>'str','link_type'=>'str','enabled'=>'bool',
            'display_order'=>'uint','permission_group'=>'str','permission_id'=>'str']));
        try { $icon = Icon::fromInput($this->request->getFile('icon', false, false), $this->filter('svg', 'str')); }
        catch (\InvalidArgumentException $e) { return $this->error($e->getMessage()); }
        $db = $this->app()->db(); $db->beginTransaction(); $newPath = '';
        try
        {
            $oldIcon = $tile->icon_id;
            if ($icon && $icon['file_path'])
            {
                $newPath = 'internal-data://ad90/custom_nav_menu/icons/'.bin2hex(random_bytes(16)).'.'.pathinfo($icon['file_path'], PATHINFO_EXTENSION);
                \XF::fs()->write($newPath, $icon['icon_data']);
                $icon['file_path'] = $newPath; $icon['icon_data'] = '';
            }
            if ($icon) { $db->insert('xf_ad90_nav_icon', $icon); $tile->icon_id = $db->lastInsertId(); }
            elseif ($this->filter('remove_icon', 'bool')) { $tile->icon_id = 0; }
            $tile->save(); $db->commit();
        }
        catch (\Throwable $e)
        {
            $db->rollback();
            if ($newPath && \XF::fs()->has($newPath)) { \XF::fs()->delete($newPath); }
            throw $e;
        }
        if ($oldIcon && $oldIcon != $tile->icon_id) { Icon::delete($oldIcon); }
        return $this->redirect($this->buildLink('custom-nav-tiles'));
    }
    public function actionDelete(ParameterBag $params)
    {
        $tile = $this->assertRecordExists('AD90\CustomNavMenu:AccountTile', $params->tile_id);
        if ($this->isPost()) { $tile->delete(); return $this->redirect($this->buildLink('custom-nav-tiles')); }
        return $this->view('AD90\CustomNavMenu:AccountTile\Delete', 'ad90_nav_tile_delete', ['tile'=>$tile]);
    }
}
