<?php

namespace AD90\CustomThreadView\Repository;

use XF\Entity\Thread;
use XF\Mvc\Entity\Finder;
use XF\Mvc\Entity\Repository;

/**
 * Unified repository for the header threads / resources panel.
 *
 * Replaces the old ThreadList / ResourceList helpers.
 * Provides lazy-load queries so the main page controller never pays the cost.
 */
class Ad90Ctv extends Repository
{
    /** Default page size, matches XF stock discussionsPerPage. */
    public const PER_PAGE = 30;

    // ------------------------------------------------------------------------
    // Options helpers
    // ------------------------------------------------------------------------

    /** Master switch. */
    public static function isEnabled(): bool
    {
        return (bool)\XF::options()->ad90_ctv_enabled;
    }

    /** Threads area switch. */
    public static function threadsEnabled(): bool
    {
        return self::isEnabled() && (bool)\XF::options()->ad90_ctv_threads;
    }

    /** Resources area switch (requires XFRM). */
    public static function resourcesEnabled(): bool
    {
        if (!self::isEnabled() || !\XF::options()->ad90_ctv_resources)
        {
            return false;
        }

        $addOn = \XF::app()->addOnManager()->getById('XFRM');

        return ($addOn !== null && $addOn->isActive())
            && class_exists(\XFRM\Entity\ResourceItem::class);
    }

    /** Infinite scroll settings. */
    public static function scrollSettings(): array
    {
        $options = \XF::options();

        $scroll = (bool)$options->ad90_ctv_scroll;
        $limit = (int)($options->ad90_ctv_scroll_limit ?? 0);

        return [
            'scroll' => $scroll,
            'limit'  => max(0, $limit),
        ];
    }

    // ------------------------------------------------------------------------
    // Thread finder
    // ------------------------------------------------------------------------

    /**
     * Builds the thread finder scoped to the current thread's node.
     *
     * @param \XF\Entity\Thread $thread
     * @return Finder
     */
    public function buildThreadFinder(Thread $thread): Finder
    {
        $visitor = \XF::visitor();

        $finder = $this->finder('XF:Thread');
        $finder->where('node_id', $thread->node_id)
            ->where('discussion_state', 'visible')
            ->where('discussion_open', 1)
            ->where('thread_id', '<>', $thread->thread_id);

        if (!$visitor->hasNodePermission($thread->node_id, 'viewOthers'))
        {
            $finder->where('user_id', $visitor->user_id);
        }

        if ($visitor->user_id && $visitor->Profile)
        {
            $ignored = array_keys($visitor->Profile->ignored);

            if ($ignored)
            {
                $finder->where('user_id', '<>', $ignored);
            }
        }

        $with = ['User', 'LastPoster', 'Forum', 'FirstPost'];

        if ($visitor->user_id)
        {
            $with[] = 'Read|' . $visitor->user_id;
        }

        return $finder
            ->with($with)
            ->order('last_post_date', 'DESC');
    }

    // ------------------------------------------------------------------------
    // Resource finder
    // ------------------------------------------------------------------------

    /**
     * Builds the resource finder scoped to the current resource's category.
     */
    public function buildResourceFinder(\XFRM\Entity\ResourceItem $resource): Finder
    {
        $visitor = \XF::visitor();

        /** @var \XFRM\Finder\ResourceItem $finder */
        $finder = $this->finder('XFRM:ResourceItem');

        $finder->where('resource_category_id', $resource->resource_category_id)
            ->where('resource_id', '<>', $resource->resource_id);

        $category = $resource->Category;
        if ($category)
        {
            $finder->applyVisibilityChecksInCategory($category);
        }
        else
        {
            $finder->where('resource_state', 'visible');
        }

        $with = ['User', 'CurrentVersion', 'Discussion'];

        return $finder
            ->with($with)
            ->order('last_update', 'DESC');
    }

    // ------------------------------------------------------------------------
    // Pagination
    // ------------------------------------------------------------------------

    /**
     * Fetches one page of threads and reports whether more rows exist.
     *
     * @param Thread $thread
     * @param int    $page
     * @return array{threads: \XF\Entity\Thread[], hasMore: bool}
     */
    public function fetchThreadPage(Thread $thread, int $page): array
    {
        $result = $this->fetchPage($thread, $page, 'thread');

        return [
            'threads' => $result['items'],
            'hasMore' => $result['hasMore'],
        ];
    }

    /**
     * Fetches one page of resources and reports whether more rows exist.
     *
     * @param \XFRM\Entity\ResourceItem $resource
     * @param int                         $page
     * @return array{resources: \XFRM\Entity\ResourceItem[], hasMore: bool}
     */
    public function fetchResourcePage(\XFRM\Entity\ResourceItem $resource, int $page): array
    {
        $result = $this->fetchPage($resource, $page, 'resource');

        return [
            'resources' => $result['items'],
            'hasMore'   => $result['hasMore'],
        ];
    }

    /**
     * Generic pagination logic shared between threads and resources.
     *
     * @param \XF\Mvc\Entity\Entity $context
     * @param string                $type  'thread'|'resource'
     * @return array{items: array<int, \XF\Mvc\Entity\Entity>, hasMore: bool}
     */
    protected function fetchPage($context, int $page, string $type): array
    {
        $page = max(1, $page);
        $perPage = self::PER_PAGE;
        $offset = ($page - 1) * $perPage;

        ['scroll' => $scroll, 'limit' => $limit] = self::scrollSettings();

        if (!$scroll)
        {
            $finder = $this->buildFinderFor($context);
            $items = $finder->limit($perPage, $offset)->fetch()->toArray();

            return [
                'items'   => $items,
                'hasMore' => false,
            ];
        }

        if ($limit > 0 && $offset >= $limit)
        {
            return [
                'items'   => [],
                'hasMore' => false,
            ];
        }

        $fetch = $perPage + 1;
        if ($limit > 0)
        {
            $fetch = min($fetch, $limit - $offset);
        }

        $finder = $this->buildFinderFor($context);
        $items = $finder->limit($fetch, $offset)->fetch()->toArray();

        $hasMore = count($items) > $perPage;

        if ($hasMore)
        {
            $items = array_slice($items, 0, $perPage, true);
        }

        if ($limit > 0 && ($offset + count($items)) >= $limit)
        {
            $hasMore = false;
        }

        return [
            'items'   => $items,
            'hasMore' => $hasMore,
        ];
    }

    /**
     * Returns the finder for the given context entity.
     *
     * @param \XF\Mvc\Entity\Entity $context
     * @return Finder
     */
    protected function buildFinderFor($context)
    {
        if ($context instanceof Thread)
        {
            return $this->buildThreadFinder($context);
        }

        return $this->buildResourceFinder($context);
    }

    // ------------------------------------------------------------------------
    // Post counts ("you wrote here N times")
    // ------------------------------------------------------------------------

    /**
     * Number of visible posts the current visitor wrote in each of the threads.
     *
     * A single grouped query feeds the "you wrote here N times" tooltip, so the
     * cost does not grow with the number of rows in the panel. Every requested
     * thread gets an entry (zero when the visitor did not post there), so the
     * template never reads a missing array key.
     *
     * xf_thread_user_post is not used here on purpose: its post_count also counts
     * soft-deleted posts, while the panel has always shown visible posts only.
     *
     * @param int[] $threadIds
     * @return array<int, int> thread_id => count
     */
    public function getThreadPostCounts(array $threadIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $threadIds)));

        $map = array_fill_keys($ids, 0);

        $visitor = \XF::visitor();

        if (!$visitor->user_id || !$ids)
        {
            return $map;
        }

        $quoteIds = array_map([$this->db(), 'quote'], $ids);
        $in = implode(',', $quoteIds);

        $rows = $this->db()->fetchAll(
            "SELECT thread_id, COUNT(*) AS total
             FROM xf_post
             WHERE user_id = ?
               AND message_state = 'visible'
               AND thread_id IN ({$in})
             GROUP BY thread_id",
            [$visitor->user_id]
        );

        foreach ($rows as $row)
        {
            $map[(int)$row['thread_id']] = (int)$row['total'];
        }

        return $map;
    }

    /**
     * Resource post counts (over resource discussions).
     *
     * @param int[] $resourceIds
     * @return array<int, int>
     */
    public function getResourcePostCounts(array $resourceIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $resourceIds)));

        $map = array_fill_keys($ids, 0);

        $visitor = \XF::visitor();

        if (!$visitor->user_id || !$ids)
        {
            return $map;
        }

        $quoteIds = array_map([$this->db(), 'quote'], $ids);
        $in = implode(',', $quoteIds);

        $rows = $this->db()->fetchAll(
            "SELECT resource_id, COUNT(*) AS total
             FROM (
                 SELECT r.resource_id
                   FROM xf_rm_resource AS r
                   INNER JOIN xf_post AS p ON p.thread_id = r.discussion_thread_id
                  WHERE r.resource_id IN ({$in})
                    AND p.user_id = ?
                    AND p.message_state = 'visible'
             ) AS matched
             GROUP BY resource_id",
            [$visitor->user_id]
        );

        foreach ($rows as $row)
        {
            $map[(int)$row['resource_id']] = (int)$row['total'];
        }

        return $map;
    }

    // ------------------------------------------------------------------------
    // SV MultiPrefix detection
    // ------------------------------------------------------------------------

    /**
     * Checks whether SV MultiPrefix is installed AND enabled.
     *
     * When it is off (disabled or removed) the templates fall back to the stock
     * single prefix, so nothing breaks and $thread.sv_prefix_ids is never read.
     *
     * @return bool
     */
    public function hasMultiPrefix(): bool
    {
        $addOn = $this->app()->addOnManager()->getById('SV/MultiPrefix');

        return $addOn !== null && $addOn->isActive();
    }
}
