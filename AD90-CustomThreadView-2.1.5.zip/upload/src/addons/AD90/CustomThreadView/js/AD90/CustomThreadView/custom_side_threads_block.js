/**
 * AD90 CustomThreadView - header threads menu.
 *
 * Port of the 2.2 inline script to XF 2.3:
 *  - jQuery is not used by the 2.3 core, so the handler is a plain XF.Element
 *  - the jQuery "scrollbar" plugin does not exist any more; scrolling is native CSS
 *  - the class names and the localStorage key are kept from the 2.2 version so the
 *    existing theme rules (.is-lefter_mdv / .is-active-fixed) keep working
 */
!function (window, document, _undefined)
{
	"use strict";

	var STORAGE_KEY = 'ForumSearchThreadsPinned',
		UNPIN_DELAY = 1500,
		HOVER_CLOSE_DELAY = 1000;

	XF.Ad90CtvMenu = XF.Element.newHandler({
		options: {
			menuSelector: '._forumSearchThreadsMenu',
			pinSelector: '._forumSearchThreads--pinButton'
		},

		menu: null,
		pin: null,
		closeTimer: null,
		unpinning: false,
		scroll: null,
		list: null,
		sentinel: null,
		observer: null,
		loading: false,

		init: function ()
		{
			this.menu = this.target.querySelector(this.options.menuSelector);
			this.pin = this.target.querySelector(this.options.pinSelector);

			if (!this.menu)
			{
				return;
			}

			if (this.isPinned())
			{
				this.applyPinned(true, false);
			}

			if (this.pin)
			{
				XF.on(this.pin, 'click', this.onPinClick.bind(this));
			}

			XF.on(this.target, 'mouseenter', this.onEnter.bind(this));
			XF.on(this.target, 'mouseleave', this.onLeave.bind(this));

			// The panel slides out under the header, so its top edge follows the header height.
			this.updateOffset();
			XF.on(window, 'resize', this.updateOffset.bind(this));
			XF.on(window, 'scroll', this.updateOffset.bind(this));

			this.initPaging();
		},

		initPaging: function ()
		{
			this.scroll = this.menu.querySelector('.js-ad90CtvScroll');
			this.list = this.menu.querySelector('.js-ad90CtvList');
			this.sentinel = this.menu.querySelector('.js-ad90CtvSentinel');

			if (!this.scroll || !this.list || !this.sentinel)
			{
				return;
			}

			if (!('IntersectionObserver' in window))
			{
				// Fallback for old engines: plain scroll listener.
				XF.on(this.scroll, 'scroll', this.onScroll.bind(this));
				return;
			}

			this.observer = new IntersectionObserver(this.onIntersect.bind(this), {
				root: this.scroll,
				rootMargin: '150px'
			});
			this.observer.observe(this.sentinel);
		},

		onScroll: function ()
		{
			var gap = this.scroll.scrollHeight - this.scroll.scrollTop - this.scroll.clientHeight;

			if (gap < 150)
			{
				this.loadMore();
			}
		},

		onIntersect: function (entries)
		{
			if (entries.some(function (entry) { return entry.isIntersecting; }))
			{
				this.loadMore();
			}
		},

		loadMore: async function ()
		{
			if (this.loading || this.scroll.dataset.hasMore !== '1')
			{
				return;
			}

			var page = parseInt(this.scroll.dataset.nextPage, 10) || 2,
				href = this.scroll.dataset.href,
				type = this.scroll.dataset.type || 'threads',
				id = type === 'resources' ? this.scroll.dataset.resourceId : this.scroll.dataset.threadId,
				idParam = type === 'resources' ? 'resource_id' : 'thread_id';

			if (!href || !id)
			{
				return;
			}

			this.loading = true;
			this.sentinel.classList.add('is-loading');

			try
			{
				var result = await XF.ajax(
					'get',
					href + '?type=' + encodeURIComponent(type) + '&' + idParam + '=' + encodeURIComponent(id) + '&page=' + page,
					{},
					null,
					// The controller replies with a raw HTML fragment, not JSON, so the
					// response must be read as text. Without dataType:'html' XF.ajax parses
					// the body as JSON, throws, and paging silently stops after one spinner.
					{ dataType: 'html', skipDefault: true }
				);

				var html = result && result.data;
				if (typeof html !== 'string' || !html)
				{
					this.stopPaging();
					return;
				}

				var wrapper = document.createElement('div');
				wrapper.innerHTML = html;

				var source = wrapper.firstElementChild;
				if (!source)
				{
					this.stopPaging();
					return;
				}

				var items = source.querySelectorAll('.discussionListItem');
				for (var i = 0; i < items.length; i++)
				{
					this.list.appendChild(items[i]);
				}

				// New nodes carry data-xf-init handlers (tooltips, previews); without
				// this they stay inert until a full page reload.
				if (XF.activate)
				{
					XF.activate(this.list);
				}

				this.scroll.dataset.nextPage = String(page + 1);
				this.scroll.dataset.hasMore = source.dataset.hasMore === '1' ? '1' : '0';

				if (this.scroll.dataset.hasMore !== '1')
				{
					this.stopPaging();
				}
			}
			catch (e)
			{
				this.stopPaging();
			}
			finally
			{
				this.loading = false;
				this.sentinel.classList.remove('is-loading');
				this.loadAgainIfVisible();
			}
		},

		/**
		 * IntersectionObserver only fires on a change of intersection. If the sentinel
		 * is still inside the viewport after a page was appended (tall panel), it would
		 * never fire again, so the list would appear stuck. Re-check manually.
		 */
		loadAgainIfVisible: function ()
		{
			if (!this.sentinel || this.scroll.dataset.hasMore !== '1')
			{
				return;
			}

			var rootRect = this.scroll.getBoundingClientRect(),
				sentinelRect = this.sentinel.getBoundingClientRect();

			if (sentinelRect.top <= rootRect.bottom + 150)
			{
				window.setTimeout(this.loadMore.bind(this), 0);
			}
		},

		stopPaging: function ()
		{
			this.scroll.dataset.hasMore = '0';

			if (this.observer)
			{
				this.observer.disconnect();
				this.observer = null;
			}
		},

		updateOffset: function ()
		{
			var header = document.querySelector('.p-navSticky--primary')
				|| document.querySelector('.p-nav')
				|| document.querySelector('.p-header');

			var top = 0;

			if (header)
			{
				top = Math.max(0, Math.round(header.getBoundingClientRect().bottom));
			}

			this.menu.style.setProperty('--ad90-ctv-top', top + 'px');
		},

		onEnter: function ()
		{
			if (this.unpinning)
			{
				return;
			}

			this.clearCloseTimer();
			this.open();
		},

		onLeave: function ()
		{
			if (this.unpinning || this.isPinned())
			{
				return;
			}

			this.clearCloseTimer();
			this.closeTimer = window.setTimeout(function ()
			{
				if (!this.isPinned() && !this.unpinning)
				{
					this.close();
				}
			}.bind(this), HOVER_CLOSE_DELAY);
		},

		onPinClick: function (e)
		{
			e.preventDefault();
			e.stopPropagation();

			if (this.isPinned())
			{
				// Unpinning keeps the menu open briefly so the click does not look like a glitch.
				this.unpinning = true;
				this.applyPinned(false, true);

				this.closeTimer = window.setTimeout(function ()
				{
					this.unpinning = false;
					this.close();
				}.bind(this), UNPIN_DELAY);
			}
			else
			{
				this.clearCloseTimer();
				this.applyPinned(true, true);
			}
		},

		open: function ()
		{
			this.menu.classList.add('active', 'is-lefter_mdv');
			this.target.classList.add('active');
		},

		close: function ()
		{
			this.menu.classList.remove('active', 'is-lefter_mdv');
			this.target.classList.remove('active');
		},

		clearCloseTimer: function ()
		{
			if (this.closeTimer)
			{
				window.clearTimeout(this.closeTimer);
				this.closeTimer = null;
			}
		},

		isPinned: function ()
		{
			try
			{
				return window.localStorage.getItem(STORAGE_KEY) === '1';
			}
			catch (e)
			{
				return false;
			}
		},

		applyPinned: function (pinned, persist)
		{
			this.menu.classList.toggle('pinned', pinned);
			this.menu.classList.toggle('is-active-fixed', pinned);
			this.target.classList.toggle('active', pinned);

			if (this.pin)
			{
				this.pin.classList.toggle('pinned', pinned);
				this.pin.setAttribute('aria-pressed', pinned ? 'true' : 'false');
			}

			if (pinned)
			{
				this.open();
			}

			if (!persist)
			{
				return;
			}

			try
			{
				if (pinned)
				{
					window.localStorage.setItem(STORAGE_KEY, '1');
				}
				else
				{
					window.localStorage.removeItem(STORAGE_KEY);
				}
			}
			catch (e)
			{
				// storage can be unavailable (private mode / quota); the toggle still works
			}
		}
	});

	XF.Element.register('ad90-ctv-menu', 'XF.Ad90CtvMenu');
}(window, document);
