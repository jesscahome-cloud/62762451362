<?php

namespace AD90\CustomThreadView\Util;

use XF\Mvc\Entity\Finder;
use XFRM\Entity\ResourceItem;

/**
 * Shared query for the header resources menu.
 *
 * Mirrors ThreadList but for XFRM resources: the panel pages through the other
 * visible resources of the current resource's category, ordered by last update.
 */
class ResourceList
{
	/** Stock page size, also the fallback limit when infinite scroll is off. */
	public const PER_PAGE = 30;

	/**
	 * Whether the header resources block is switched on.
	 *
	 * The master option (ad90_ctv_enabled) gates everything; the per-area option
	 * (ad90_ctv_resources) switches just the resources panel. XFRM has to be
	 * installed and enabled, otherwise the entity/finder classes do not exist.
	 */
	public static function isEnabled(): bool
	{
		if (!ThreadList::isEnabled() || !\XF::options()->ad90_ctv_resources)
		{
			return false;
		}

		$addOn = \XF::app()->addOnManager()->getById('XFRM');

		return ($addOn !== null && $addOn->active)
			&& class_exists(ResourceItem::class);
	}

	/**
	 * Infinite scroll settings resolved from the add-on options.
	 *
	 * Shared with ThreadList so a single pair of options drives both panels.
	 *
	 * @return array{scroll: bool, limit: int} limit of 0 means unlimited.
	 */
	public static function scrollSettings(): array
	{
		return ThreadList::scrollSettings();
	}

	public static function buildFinder(ResourceItem $resource): Finder
	{
		$visitor = \XF::visitor();

		/** @var \XFRM\Finder\ResourceItem $finder */
		$finder = \XF::finder('XFRM:ResourceItem');

		$finder->where('resource_category_id', $resource->resource_category_id)
			->where('resource_id', '<>', $resource->resource_id);

		// Category-scoped visibility: visible rows, plus the visitor's own pending
		// ones when they moderate the category.
		$category = $resource->Category;
		if ($category)
		{
			$finder->applyVisibilityChecksInCategory($category);
		}
		else
		{
			$finder->where('resource_state', 'visible');
		}

		if ($visitor->isIgnoring($resource->user_id))
		{
			// No point hiding rows by author here; the panel simply lists resources.
		}

		$with = ['User', 'CurrentVersion', 'Discussion'];

		return $finder
			->with($with)
			->order('last_update', 'DESC');
	}

	/**
	 * Fetches one page and reports whether more rows exist behind it.
	 *
	 * @return array{resources: array<int, ResourceItem>, hasMore: bool}
	 */
	public static function fetchPage(ResourceItem $resource, int $page): array
	{
		$page = max(1, $page);
		$perPage = self::PER_PAGE;
		$offset = ($page - 1) * $perPage;

		['scroll' => $scroll, 'limit' => $limit] = self::scrollSettings();

		if (!$scroll)
		{
			$resources = self::buildFinder($resource)
				->limit($perPage, $offset)
				->fetch()
				->toArray();

			return [
				'resources' => $resources,
				'hasMore' => false,
			];
		}

		if ($limit > 0 && $offset >= $limit)
		{
			return [
				'resources' => [],
				'hasMore' => false,
			];
		}

		$fetch = $perPage + 1;
		if ($limit > 0)
		{
			$fetch = min($fetch, $limit - $offset);
		}

		$resources = self::buildFinder($resource)
			->limit($fetch, $offset)
			->fetch()
			->toArray();

		$hasMore = count($resources) > $perPage;

		if ($hasMore)
		{
			$resources = array_slice($resources, 0, $perPage, true);
		}

		if ($limit > 0 && ($offset + count($resources)) >= $limit)
		{
			$hasMore = false;
		}

		return [
			'resources' => $resources,
			'hasMore' => $hasMore,
		];
	}

	/**
	 * Number of visible posts the current visitor wrote in each resource's discussion.
	 *
	 * Resources without a discussion thread are simply absent from the query and
	 * get a zero entry, so the template never reads a missing array key.
	 *
	 * @param int[] $resourceIds
	 * @return array<int, int> resource_id => count
	 */
	public static function getUserPostCounts(array $resourceIds): array
	{
		$ids = array_values(array_filter(array_map('intval', $resourceIds)));

		$map = array_fill_keys($ids, 0);

		$visitor = \XF::visitor();

		if (!$visitor->user_id || !$ids)
		{
			return $map;
		}

		$in = implode(',', $ids);

		// One grouped query over the resources' discussion threads. Resources with
		// no discussion contribute nothing (their entry stays zero).
		$rows = \XF::db()->fetchAll(
			"SELECT resource_id, COUNT(*) AS total
			 FROM (
				SELECT r.resource_id
				 FROM xf_rm_resource AS r
				 INNER JOIN xf_post AS p ON p.thread_id = r.discussion_thread_id
				 WHERE r.resource_id IN ({$in})
					AND p.user_id = ?
					AND p.message_state = 'visible'
			 ) AS matched
			 GROUP BY resource_id",
			[$visitor->user_id]
		);

		foreach ($rows as $row)
		{
			$map[(int)$row['resource_id']] = (int)$row['total'];
		}

		return $map;
	}
}
