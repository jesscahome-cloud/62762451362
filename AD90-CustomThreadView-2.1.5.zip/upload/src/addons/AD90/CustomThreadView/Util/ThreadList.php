<?php

namespace AD90\CustomThreadView\Util;

use XF\Entity\Thread;
use XF\Mvc\Entity\Finder;

/**
 * Shared query for the header threads menu.
 *
 * The menu pages through every open thread of the forum, so the finder has to
 * stay identical between the first render and the ajax page loads.
 */
class ThreadList
{
	/** Stock page size, also the fallback limit when infinite scroll is off. */
	public const PER_PAGE = 30;

	/**
	 * Whether the header threads block is switched on.
	 *
	 * The master option (ad90_ctv_enabled) gates everything; ad90_ctv_threads
	 * switches just the discussions panel.
	 */
	public static function isEnabled(): bool
	{
		return (bool)\XF::options()->ad90_ctv_enabled
			&& (bool)\XF::options()->ad90_ctv_threads;
	}

	/**
	 * The master switch only (used by the ajax endpoint to accept either type).
	 */
	public static function isEnabledAny(): bool
	{
		return (bool)\XF::options()->ad90_ctv_enabled;
	}

	/**
	 * Infinite scroll settings resolved from the add-on options.
	 *
	 * @return array{scroll: bool, limit: int} limit of 0 means unlimited.
	 */
	public static function scrollSettings(): array
	{
		$options = \XF::options();

		$scroll = !empty($options->ad90_ctv_scroll);
		$limit = (int)($options->ad90_ctv_scroll_limit ?? 0);

		return [
			'scroll' => $scroll,
			'limit' => max(0, $limit),
		];
	}

	public static function buildFinder(Thread $thread): Finder
	{
		$visitor = \XF::visitor();

		$finder = \XF::finder('XF:Thread');
		$finder->where('node_id', $thread->node_id)
			->where('discussion_state', 'visible')
			->where('discussion_open', 1)
			->where('thread_id', '<>', $thread->thread_id);

		if (!$visitor->hasNodePermission($thread->node_id, 'viewOthers'))
		{
			$finder->where('user_id', $visitor->user_id);
		}

		if ($visitor->user_id && $visitor->Profile)
		{
			$ignored = array_keys($visitor->Profile->ignored);

			if ($ignored)
			{
				$finder->where('user_id', '<>', $ignored);
			}
		}

		$with = ['User', 'LastPoster', 'Forum', 'FirstPost'];

		if ($visitor->user_id)
		{
			// Without this every isUnread() call in the template hits the database.
			$with[] = 'Read|' . $visitor->user_id;
		}

		return $finder
			->with($with)
			->order('last_post_date', 'DESC');
	}

	/**
	 * Fetches one page and reports whether more rows exist behind it.
	 *
	 * The infinite-scroll option controls how many rows are returned and whether
	 * the client is allowed to ask for the next page:
	 *  - scroll off  -> a single stock page of PER_PAGE, hasMore always false
	 *  - scroll on   -> pages of PER_PAGE, hasMore true until the optional limit
	 *
	 * @return array{threads: array<int, Thread>, hasMore: bool}
	 */
	public static function fetchPage(Thread $thread, int $page): array
	{
		$page = max(1, $page);
		$perPage = self::PER_PAGE;
		$offset = ($page - 1) * $perPage;

		['scroll' => $scroll, 'limit' => $limit] = self::scrollSettings();

		// Infinite scroll off: behave like the stock forum, one page, no paging.
		if (!$scroll)
		{
			$threads = self::buildFinder($thread)
				->limit($perPage, $offset)
				->fetch()
				->toArray();

			return [
				'threads' => $threads,
				'hasMore' => false,
			];
		}

		// A configured total limit was already reached: nothing more to show.
		if ($limit > 0 && $offset >= $limit)
		{
			return [
				'threads' => [],
				'hasMore' => false,
			];
		}

		// One extra row is the cheapest way to know whether another page exists,
		// but never fetch past the configured limit.
		$fetch = $perPage + 1;
		if ($limit > 0)
		{
			$fetch = min($fetch, $limit - $offset);
		}

		$threads = self::buildFinder($thread)
			->limit($fetch, $offset)
			->fetch()
			->toArray();

		$hasMore = count($threads) > $perPage;

		if ($hasMore)
		{
			$threads = array_slice($threads, 0, $perPage, true);
		}

		if ($limit > 0 && ($offset + count($threads)) >= $limit)
		{
			$hasMore = false;
		}

		return [
			'threads' => $threads,
			'hasMore' => $hasMore,
		];
	}

	/**
	 * Number of visible posts the current visitor wrote in each of the threads.
	 *
	 * A single grouped query feeds the "you wrote here N times" tooltip, so the
	 * cost does not grow with the number of rows in the panel. Every requested
	 * thread gets an entry (zero when the visitor did not post there), so the
	 * template never reads a missing array key.
	 *
	 * @param int[] $threadIds
	 * @return array<int, int> thread_id => count
	 */
	public static function getUserPostCounts(array $threadIds): array
	{
		$ids = array_values(array_filter(array_map('intval', $threadIds)));

		$map = array_fill_keys($ids, 0);

		$visitor = \XF::visitor();

		if (!$visitor->user_id || !$ids)
		{
			return $map;
		}

		$in = implode(',', $ids);

		$rows = \XF::db()->fetchAll(
			"SELECT thread_id, COUNT(*) AS total
			 FROM xf_post
			 WHERE user_id = ?
				AND message_state = 'visible'
				AND thread_id IN ({$in})
			 GROUP BY thread_id",
			[$visitor->user_id]
		);

		foreach ($rows as $row)
		{
			$map[(int)$row['thread_id']] = (int)$row['total'];
		}

		return $map;
	}
}
