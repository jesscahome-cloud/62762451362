<?php

namespace AD90\CustomThreadView\XFRM\Pub\Controller;

use AD90\CustomThreadView\Repository\Ad90Ctv;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\View;

/**
 * Resource page controller — attaches header menu buttons without loading the list.
 *
 * The actual list is loaded lazily via the ajax endpoint (Threads::actionResources).
 * No list query is executed here.
 */
class ResourceItem extends XFCP_ResourceItem
{
	/**
	 * The resource page itself is rendered by actionView (actionIndex reroutes
	 * to it when a resource_id is present), so the menu setup is attached here.
	 */
	public function actionView(ParameterBag $params)
	{
		$reply = parent::actionView($params);

		if ($reply instanceof View && !$this->request->isXhr())
		{
			$resource = $reply->getParam('resource');

			if ($resource instanceof \XFRM\Entity\ResourceItem && $resource->resource_id)
			{
				try
				{
					$this->ad90CtvSetupButtons($resource);
				}
				catch (\Throwable $e)
				{
					// A broken side menu must never take the resource page down.
					\XF::logException($e, false, 'AD90 CustomThreadView: ');
				}
			}
		}

		return $reply;
	}

	/**
	 * Sets up PAGE_CONTAINER params for the header buttons only.
	 * Does NOT load the resource list.
	 */
	protected function ad90CtvSetupButtons(\XFRM\Entity\ResourceItem $resource): void
	{
		if (!Ad90Ctv::resourcesEnabled())
		{
			return;
		}

		if (!$resource->canView())
		{
			return;
		}

		$templater = $this->app->templater();
		$templater->setPageParams([
			'ad90CtvShowButton' => true,
			'ad90CtvActiveThreadId' => 0,
			'ad90CtvActiveResourceId' => $resource->resource_id,
			'ad90CtvListType' => 'resources',
		]);
	}
}
