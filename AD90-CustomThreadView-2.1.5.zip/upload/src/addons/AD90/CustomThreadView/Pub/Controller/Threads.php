<?php

namespace AD90\CustomThreadView\Pub\Controller;

use AD90\CustomThreadView\Repository\Ad90Ctv;
use XF\Mvc\ParameterBag;
use XF\Pub\Controller\AbstractController;

/**
 * Lazy-load endpoints for the header threads / resources panel.
 *
 * Two actions (threads, resources) reached via the ad90-ctv sub-path
 * (ad90-ctv/threads, ad90-ctv/resources). Each returns a standard XF json
 * reply whose data.html fragment is inserted on the client via
 * XF.setupHtmlInsert (see custom_side_threads_block.js). No custom Raw view.
 *
 * Pagination state (hasMore / nextPage) travels inside the rendered container's
 * data attributes, so the reply stays a plain fragment render.
 *
 * Works for guests: visibility is enforced by the XF finders / canView() only.
 */
class Threads extends AbstractController
{
	/**
	 * Backwards-compatible entry point.
	 *
	 * 2.0.8 used a single ad90-ctv endpoint with a "type" parameter. The route
	 * prefix must stay (Recentpages references it), so the old call shape keeps
	 * working: ad90-ctv?type=resources delegates to actionResources, anything
	 * else to actionThreads.
	 *
	 * @return \XF\Mvc\Reply\AbstractReply
	 */
	public function actionIndex(ParameterBag $params)
	{
		$type = $this->filter('type', 'str');

		if ($type === 'resources')
		{
			return $this->actionResources($params);
		}

		return $this->actionThreads($params);
	}

	/** GET ad90-ctv/threads — one page of forum threads. */
	public function actionThreads(ParameterBag $params)
	{
		if (!Ad90Ctv::threadsEnabled())
		{
			return $this->notFound();
		}

		$page = max(1, $this->filter('page', 'uint'));

		$threadId = $this->filter('thread_id', 'uint');

		/** @var \XF\Entity\Thread|null $thread */
		$thread = $this->em()->find('XF:Thread', $threadId);

		if (!$thread || !$thread->canView())
		{
			return $this->notFound(\XF::phrase('requested_thread_not_found'));
		}

		/** @var Ad90Ctv $repo */
		$repo = $this->repository('AD90\CustomThreadView:Ad90Ctv');
		$result = $repo->fetchThreadPage($thread, $page);

		// The current thread is never listed: the panel shows the other threads of
		// the forum only (the finder already excludes it, so the list stays dense).
		$threads = $result['threads'];

		$reply = $this->view('', 'ad90_ctv_threads_page', [
			'threads' => $threads,
			'activeThreadId' => $thread->thread_id,
			'userPostCounts' => $repo->getThreadPostCounts(array_keys($threads)),
			'hasMore' => $result['hasMore'],
			'nextPage' => $page + 1,
			'hasMultiPrefix' => $repo->hasMultiPrefix(),
		]);
		$reply->setResponseType('json');

		return $reply;
	}

	/** GET ad90-ctv/resources — one page of XFRM resources in the category. */
	public function actionResources(ParameterBag $params)
	{
		if (!Ad90Ctv::resourcesEnabled())
		{
			return $this->notFound();
		}

		$page = max(1, $this->filter('page', 'uint'));
		$resourceId = $this->filter('resource_id', 'uint');

		/** @var \XFRM\Entity\ResourceItem|null $resource */
		$resource = $this->em()->find('XFRM:ResourceItem', $resourceId);

		if (!$resource || !$resource->canView())
		{
			return $this->notFound();
		}

		/** @var Ad90Ctv $repo */
		$repo = $this->repository('AD90\CustomThreadView:Ad90Ctv');
		$result = $repo->fetchResourcePage($resource, $page);

		// The current resource is never listed, same as the current thread.
		$resources = $result['resources'];

		$reply = $this->view('', 'ad90_ctv_resources_page', [
			'resources' => $resources,
			'activeResourceId' => $resource->resource_id,
			'userPostCounts' => $repo->getResourcePostCounts(array_keys($resources)),
			'hasMore' => $result['hasMore'],
			'nextPage' => $page + 1,
			'hasMultiPrefix' => $repo->hasMultiPrefix(),
		]);
		$reply->setResponseType('json');

		return $reply;
	}

	/**
	 * Whether the given thread should be shown as the current (first) row.
	 */
	protected function threadVisibleToVisitor(\XF\Entity\Thread $thread): bool
	{
		$visitor = \XF::visitor();

		return $thread->discussion_open
			&& $thread->discussion_state === 'visible'
			&& !$visitor->isIgnoring($thread->user_id);
	}
}
