<?php

namespace AD90\CustomThreadView\Pub\Controller;

use AD90\CustomThreadView\Repository\Ad90Ctv;
use XF\Entity\Thread as ThreadEntity;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\View;

/**
 * Thread page controller — attaches header menu data without loading the list.
 *
 * The actual list is loaded lazily via the ajax endpoint (Threads::actionThreads).
 * This controller only sets up the button markup via PAGE_CONTAINER params.
 * No list query is executed here.
 */
class Thread extends XFCP_Thread
{
	public function actionIndex(ParameterBag $params)
	{
		$reply = parent::actionIndex($params);

		if ($reply instanceof View && !$this->request->isXhr())
		{
			$thread = $reply->getParam('thread');

			if ($thread instanceof ThreadEntity && $thread->node_id)
			{
				try
				{
					$this->ad90CtvSetupButtons($thread);
				}
				catch (\Throwable $e)
				{
					\XF::logException($e, false, 'AD90 CustomThreadView: ');
				}
			}
		}

		return $reply;
	}

	/**
	 * Sets up PAGE_CONTAINER params for the header buttons only.
	 * Does NOT load the thread list.
	 */
	protected function ad90CtvSetupButtons(ThreadEntity $thread): void
	{
		if (!Ad90Ctv::threadsEnabled())
		{
			return;
		}

		$visitor = \XF::visitor();

		// Check if current thread is visible to this visitor.
		$canSeeCurrent = $thread->discussion_open
			&& $thread->discussion_state == 'visible'
			&& !$visitor->isIgnoring($thread->user_id);

		// Check if the visitor can view this thread at all.
		$canViewThread = $thread->canView();

		if (!$canSeeCurrent || !$canViewThread)
		{
			return;
		}

		$templater = $this->app->templater();
		$templater->setPageParams([
			'ad90CtvShowButton' => true,
			'ad90CtvActiveThreadId' => $thread->thread_id,
			'ad90CtvActiveResourceId' => 0,
			'ad90CtvListType' => 'threads',
		]);
	}
}
