<?php

namespace AD90\CustomThreadView\Pub\View;

use XF\Mvc\View;

/**
 * Renders a template without the surrounding page, for the ajax thread pages.
 *
 * XF's stock View has no renderRaw(), so the raw renderer would return an
 * empty body; this class supplies it.
 */
class Raw extends View
{
	public function renderRaw()
	{
		return $this->renderTemplate($this->templateName, $this->params);
	}
}
