/**
 * AD90 CustomThreadView — header threads/resources panel.
 *
 * The page itself renders only the buttons (see ad90_ctv_header template).
 * The list is loaded lazily over the ad90-ctv/{threads|resources} endpoints:
 *  - on the first hover/focus of the button (mouseenter starts the request so
 *    the data is ready by the time the panel slides out), or
 *  - immediately on init when the panel is pinned in localStorage.
 * Once loaded, infinite scroll pages through the same endpoint.
 *
 * AJAX replies are standard XF json fragments: response.html is handed to
 * XF.setupHtmlInsert, which inserts the nodes and activates their handlers
 * (tooltip / preview-tooltip). Pagination state lives in the inserted
 * container's data-has-more / data-next-page attributes.
 *
 * Plain XF.Element handler (XF 2.3 core does not ship jQuery).
 */
!function (window, document)
{
	"use strict";

	var STORAGE_KEY = 'ad90_ctv_pinned',
		LEGACY_KEY = 'ForumSearchThreadsPinned';

	XF.Ad90CtvMenu = XF.Element.newHandler({
		options: {
			menuSelector: '.ad90CtvMenu',
			pinSelector: '.ad90Ctv--pinButton',
			scrollSelector: '.ad90CtvScroll',
			listSelector: '.ad90CtvList',
			sentinelSelector: '.ad90CtvSentinel',
			itemSelector: '.ad90Ctv-item',
			hoverCloseDelay: 1000,
			unpinDelay: 1500,
			rootMargin: 150
		},

		menu: null,
		pin: null,
		closeTimer: null,
		unpinning: false,
		hoverBound: false,
		hovering: false,
		loaded: false,
		loading: false,
		// A load was requested while another one was running (see requestMore).
		pendingMore: false,
		failed: false,
		empty: false,
		scroll: null,
		list: null,
		sentinel: null,
		observer: null,
		offsetHandler: null,

		// thumb state
		thumb: null,
		thumbTimer: null,
		drag: null,

		// pagination state mirrored from the container data-* attributes
		href: '',
		hasMore: false,
		nextPage: 2,

		init: function ()
		{
			this.menu = this.target.querySelector(this.options.menuSelector);
			this.pin = this.target.querySelector(this.options.pinSelector);

			if (!this.menu)
			{
				return;
			}

			this.migrateStorage();
			this.href = this.menu.dataset.href || '';

			if (this.isPinned() && this.isPinAvailable())
			{
				this.applyPinned(true, false);
				this.ensureLoaded();
			}
			else
			{
				// The pin button is hidden on narrow screens (see the LESS media
				// query), so a stored pin is not applied there: the panel keeps
				// working on hover and the pin comes back on a wide viewport.
				this.bindHover();
			}

			if (this.pin)
			{
				XF.on(this.pin, 'click.ad90Ctv', this.onPinClick.bind(this));
			}

			// The panel slides out under the sticky header, so its top edge follows the header height.
			this.updateOffset();
			this.offsetHandler = this.updateOffset.bind(this);
			XF.on(window, 'resize.ad90Ctv', this.offsetHandler);
			XF.on(window, 'scroll.ad90Ctv', this.offsetHandler);
			XF.on(window, 'resize.ad90Ctv', this.syncPinAvailability.bind(this));
		},

		destroy: function ()
		{
			this.clearCloseTimer();

			if (this.observer)
			{
				this.observer.disconnect();
				this.observer = null;
			}

			if (this.thumbResizeObserver)
			{
				this.thumbResizeObserver.disconnect();
				this.thumbResizeObserver = null;
			}

			if (this.scroll)
			{
				XF.off(this.scroll, 'scroll.ad90CtvThumb');
				XF.off(this.scroll, 'scroll.ad90CtvPaging');
			}

			if (this.thumb)
			{
				XF.off(this.thumb, 'pointerdown.ad90CtvThumb');
				XF.off(this.thumb, 'pointermove.ad90CtvThumb');
				XF.off(this.thumb, 'pointerup.ad90CtvThumb');
				XF.off(this.thumb, 'pointercancel.ad90CtvThumb');
			}

			window.clearTimeout(this.thumbTimer);

			XF.off(window, 'resize.ad90Ctv', this.offsetHandler);
			XF.off(window, 'scroll.ad90Ctv', this.offsetHandler);

			if (this.target)
			{
				XF.off(this.target, 'mouseenter.ad90Ctv');
				XF.off(this.target, 'mouseleave.ad90Ctv');
			}

			if (this.pin)
			{
				XF.off(this.pin, 'click.ad90Ctv');
			}
		},

		/* ---- storage ---- */
		migrateStorage: function ()
		{
			try
			{
				if (localStorage.getItem(STORAGE_KEY) === null
					&& localStorage.getItem(LEGACY_KEY) === '1')
				{
					localStorage.setItem(STORAGE_KEY, '1');
					localStorage.removeItem(LEGACY_KEY);
				}
			}
			catch (e)
			{
				// storage can be unavailable (private mode / quota)
			}
		},

		isPinned: function ()
		{
			try
			{
				return localStorage.getItem(STORAGE_KEY) === '1';
			}
			catch (e)
			{
				return false;
			}
		},

		/**
		 * Whether the panel is pinned right now (not just stored as pinned).
		 *
		 * The stored value survives a narrow viewport on purpose, but the panel is
		 * not actually pinned there, so hover-close has to look at the live class
		 * instead of localStorage.
		 */
		isPinnedNow: function ()
		{
			return this.menu.classList.contains('pinned');
		},

		/**
		 * Whether the pin control is actually usable right now.
		 *
		 * On narrow viewports the button is hidden by CSS, because a permanently
		 * pinned 380px panel would cover the page content. offsetParent is null for
		 * display:none elements, which is exactly the signal needed here.
		 */
		/**
		 * Whether pinning is allowed by the current layout.
		 *
		 * On narrow viewports the pin button is hidden by CSS (see the LESS media
		 * query), because a permanently pinned panel would cover the page content.
		 * The same breakpoint is rendered into data-pin-hide-width, so the check
		 * stays in sync with the stylesheet and does not depend on whether the
		 * button happens to be visible in the current hover state.
		 */
		isPinAvailable: function ()
		{
			var breakpoint = this.target.dataset.pinHideWidth || '';

			if (!breakpoint || !window.matchMedia)
			{
				return !!this.pin;
			}

			return !window.matchMedia('(max-width: ' + breakpoint + ')').matches;
		},

		/**
		 * Keeps the panel in sync when the viewport crosses the pin breakpoint:
		 * hides the pinned state when the button disappears and restores it from
		 * localStorage when the button comes back.
		 */
		syncPinAvailability: function ()
		{
			if (this.isPinAvailable())
			{
				if (!this.menu.classList.contains('pinned') && this.isPinned())
				{
					this.applyPinned(true, false);
					this.ensureLoaded();
				}

				return;
			}

			if (!this.menu.classList.contains('pinned'))
			{
				return;
			}

			// The stored value is kept on purpose: it belongs to the wide layout.
			this.applyPinned(false, false);
			this.unpinning = false;
			this.clearCloseTimer();
			this.close();
			this.bindHover();
		},

		/* ---- hover / open ---- */
		bindHover: function ()
		{
			if (this.hoverBound)
			{
				return;
			}

			this.hoverBound = true;
			XF.on(this.target, 'mouseenter.ad90Ctv', this.onEnter.bind(this));
			XF.on(this.target, 'mouseleave.ad90Ctv', this.onLeave.bind(this));
		},

		onEnter: function ()
		{
			// Nothing to list in this section: hovering does nothing, so the block
			// stays a plain "back" button (see markEmpty).
			if (this.unpinning || this.empty)
			{
				return;
			}

			this.hovering = true;
			this.clearCloseTimer();
			this.open();
			this.ensureLoaded();
		},

		onLeave: function ()
		{
			this.hovering = false;

			if (this.unpinning || this.isPinnedNow())
			{
				return;
			}

			this.clearCloseTimer();
			var self = this;
			this.closeTimer = window.setTimeout(function ()
			{
				if (!self.isPinnedNow() && !self.unpinning)
				{
					self.close();
				}
			}, this.options.hoverCloseDelay);
		},

		/* ---- pin / unpin ---- */
		onPinClick: function (e)
		{
			e.preventDefault();
			e.stopPropagation();

			if (this.isPinnedNow())
			{
				// Unpinning keeps the menu open briefly so the click does not look like a glitch.
				this.clearCloseTimer();
				this.unpinning = true;
				this.applyPinned(false, true);

				var self = this;
				this.closeTimer = window.setTimeout(function ()
				{
					self.unpinning = false;
					self.close();
					self.bindHover();
				}, this.options.unpinDelay);
			}
			else
			{
				this.clearCloseTimer();
				this.applyPinned(true, true);
				this.ensureLoaded();
			}
		},

		applyPinned: function (pinned, persist)
		{
			// An empty section has no panel to pin.
			if (pinned && this.empty)
			{
				return;
			}

			this.menu.classList.toggle('pinned', pinned);

			// The block's .active class is what reveals the pin button, and it has
			// to follow the panel, not the pin flag: unpinning keeps the panel open
			// for unpinDelay (see onPinClick), so dropping .active here would hide
			// the button while the panel is still on screen. open()/close() own it.

			if (this.pin)
			{
				this.pin.classList.toggle('pinned', pinned);
				this.pin.setAttribute('aria-pressed', pinned ? 'true' : 'false');
			}

			if (pinned)
			{
				this.open();
			}

			if (!persist)
			{
				return;
			}

			try
			{
				if (pinned)
				{
					localStorage.setItem(STORAGE_KEY, '1');
				}
				else
				{
					localStorage.removeItem(STORAGE_KEY);
				}
			}
			catch (e)
			{
				// storage can be unavailable; the toggle still works
			}
		},

		open: function ()
		{
			// Nothing to show: the panel never slides out (see markEmpty).
			if (this.empty)
			{
				return;
			}

			this.menu.classList.add('active');
			this.target.classList.add('active');
		},

		close: function ()
		{
			this.menu.classList.remove('active');
			this.target.classList.remove('active');
		},

		clearCloseTimer: function ()
		{
			if (this.closeTimer)
			{
				window.clearTimeout(this.closeTimer);
				this.closeTimer = null;
			}
		},

		/* ---- lazy load (first page) ---- */
		ensureLoaded: function ()
		{
			if (this.loaded || this.loading || this.failed || !this.href)
			{
				return;
			}

			this.loading = true;
			this.showPanelLoading(true);

			var self = this;
			XF.ajax('get', this.href, this.pageParams(1), null, this.ajaxOptions())
				.then(function (result)
				{
					if (!self.readReply(result))
					{
						return;
					}

					var data = result.data;

					XF.setupHtmlInsert(data.html, function (html, container, onComplete)
					{
						return self.attachPanel(html, onComplete);
					});
				})
				.then(function ()
				{
					self.loading = false;
					self.showPanelLoading(false);

					// The paging observer/handler are bound inside attachPanel, i.e.
					// while `loading` was still true: a request from that window is
					// remembered in pendingMore and replayed here.
					if (self.loaded)
					{
						self.checkSentinel();
					}
				});
		},

		/**
		 * Request options for the background list loads.
		 *
		 * The panel is loaded silently, so the stock XF error reporting (an alert
		 * or an error overlay on any 4xx/5xx) must not fire: the failure is shown
		 * inside the panel instead (see showError).
		 */
		ajaxOptions: function ()
		{
			return { skipDefault: true };
		},

		/**
		 * Normalises an XF.ajax result. The promise is never rejected: failures
		 * arrive as {request, error} or as {request, response, data} with a
		 * non-2xx status, and a successful json reply nests the payload in .data.
		 *
		 * @returns {boolean} true when result.data holds a rendered fragment.
		 */
		readReply: function (result)
		{
			if (!result || result.error || !result.data)
			{
				this.showError();
				return false;
			}

			if (result.response && !result.response.ok)
			{
				this.showError();
				return false;
			}

			if (!result.data.html)
			{
				this.showError();
				return false;
			}

			return true;
		},

		/**
		 * While the very first page is being fetched the panel has no list yet,
		 * so show the stock XF loading state instead of an empty block.
		 */
		showPanelLoading: function (show)
		{
			this.menu.classList.toggle('is-loading', show);
		},

		/**
		 * The ajax fragment is the full scroll container (.ad90CtvScroll).
		 * setupHtmlInsert hands us the parsed root element; adopt it into the menu.
		 *
		 * The fragment is moved into the menu, so the stock XF activation
		 * (tooltip / preview-tooltip handlers) is run by us on the list after it
		 * is attached: onComplete(false, list) activates the list subtree.
		 * Returning false stops setupHtmlInsert from activating the detached
		 * wrapper instead.
		 */
		attachPanel: function (html, onComplete)
		{
			if (!html)
			{
				this.showPanelLoading(false);
				this.showError();
				return false;
			}

			var scroll = html.matches(this.options.scrollSelector)
				? html
				: html.querySelector(this.options.scrollSelector);

			if (!scroll)
			{
				this.showPanelLoading(false);
				this.showError();
				return false;
			}

			// The fragment root is the positioning wrapper (.ad90CtvScrollWrap) that
			// also holds the custom thumb; adopt the whole wrapper, not just the
			// scroll element, so the thumb node survives.
			var root = scroll.closest('.ad90CtvScrollWrap') || scroll;

			this.menu.innerHTML = '';
			this.menu.appendChild(root);

			this.scroll = scroll;
			this.list = scroll.querySelector(this.options.listSelector);
			this.sentinel = scroll.querySelector(this.options.sentinelSelector);

			if (!this.list)
			{
				this.showPanelLoading(false);
				this.showError();
				return false;
			}

			this.readState(this.scroll);
			this.loaded = true;
			this.showPanelLoading(false);
			this.showLoading(false);

			this.initThumb();
			if (typeof onComplete === 'function')
			{
				onComplete(false, this.list);
			}

			// An empty list has nothing to show: the panel stays closed and the pin
			// button is hidden, so hovering the block does nothing but reveal the
			// back button (which stays a plain link).
			if (!this.list.querySelector(this.options.itemSelector))
			{
				this.markEmpty();
				return false;
			}

			this.initPaging();
			this.loadAgainIfVisible();

			return false;
		},

		/**
		 * Nothing to list in this section (the current thread/resource is the only
		 * one). The panel is closed and never opened again, the pin button is
		 * hidden by CSS, and the block is reduced to the back button.
		 *
		 * The first page is only fetched after the panel was opened, so the user
		 * may already see it: closing here is what turns a would-be empty panel
		 * into a plain back button.
		 */
		markEmpty: function ()
		{
			this.empty = true;

			this.clearCloseTimer();
			this.menu.classList.remove('active', 'pinned', 'is-loading');
			this.target.classList.remove('active');
			this.target.classList.add('is-empty');

			if (this.pin)
			{
				this.pin.classList.remove('pinned');
				this.pin.setAttribute('aria-pressed', 'false');
			}

			// Drop any stored pin: it would be re-applied on the next page load.
			try
			{
				window.localStorage.removeItem(STORAGE_KEY);
			}
			catch (e)
			{
				// storage can be unavailable
			}
		},

		/* ---- pagination ---- */
		/**
		 * Query params for one page of the list.
		 *
		 * Both IDs are always rendered by the template, and an unused one is "0"
		 * (a truthy string), so the id is selected by the panel type instead of
		 * by checking which dataset value is present.
		 */
		pageParams: function (page)
		{
			var params = { page: page },
				type = this.menu.dataset.type || 'threads';

			if (type === 'resources')
			{
				if (this.menu.dataset.resourceId && this.menu.dataset.resourceId !== '0')
				{
					params.resource_id = this.menu.dataset.resourceId;
				}
			}
			else if (this.menu.dataset.threadId && this.menu.dataset.threadId !== '0')
			{
				params.thread_id = this.menu.dataset.threadId;
			}

			return params;
		},

		readState: function (container)
		{
			this.hasMore = container.dataset.hasMore === '1';
			this.nextPage = parseInt(container.dataset.nextPage, 10) || 2;

			// Only the first scroll container stays in the DOM: the wrappers of the
			// following pages are dropped once their rows were moved into the list.
			// Mirror the state onto the live container so it never goes stale.
			if (this.scroll && container !== this.scroll)
			{
				this.scroll.dataset.hasMore = this.hasMore ? '1' : '0';
				this.scroll.dataset.nextPage = this.nextPage;
			}
		},

		initPaging: function ()
		{
			if (!this.scroll || !this.list || !this.sentinel || !this.hasMore)
			{
				return;
			}

			var self = this;

			// Scroll is the primary trigger. It fires on every wheel/touch move,
			// so it keeps working in the case IntersectionObserver cannot cover:
			// the sentinel never leaves the viewport, therefore its intersection
			// never changes and the observer stays silent (see checkSentinel).
			XF.on(this.scroll, 'scroll.ad90CtvPaging', function ()
			{
				self.throttledOnScroll();
			}, { passive: true });

			if (!('IntersectionObserver' in window))
			{
				return;
			}

			this.observer = new IntersectionObserver(function (entries)
			{
				if (entries.some(function (entry) { return entry.isIntersecting; }))
				{
					self.requestMore();
				}
			}, {
				root: this.scroll,
				rootMargin: this.options.rootMargin + 'px'
			});

			this.observer.observe(this.sentinel);
		},

		throttledOnScroll: function ()
		{
			var self = this;
			if (this.scroll._raf)
			{
				return;
			}

			this.scroll._raf = window.requestAnimationFrame(function ()
			{
				self.scroll._raf = null;
				self.checkSentinel();
			});
		},

		/**
		 * Ask for the next page without ever losing the request.
		 *
		 * The observer and the scroll handler are live while the first page is
		 * still being fetched (attachPanel runs inside the ajax callback, before
		 * the handler clears `loading`). A request arriving in that window used
		 * to be dropped: the observer had already fired, its intersection did not
		 * change afterwards, and the list stayed stuck until the sentinel was
		 * scrolled out of view and back. Remember the request instead and replay
		 * it once the current load settles.
		 */
		requestMore: function ()
		{
			if (this.failed || !this.hasMore)
			{
				return;
			}

			if (this.loading)
			{
				this.pendingMore = true;
				return;
			}

			this.loadMore();
		},

		/**
		 * Is the sentinel row (or its reserved area) inside the scroll viewport?
		 *
		 * Geometry, not the observer state: the observer only reports changes of
		 * intersection, so a sentinel that stayed visible across an append never
		 * fires again. Both edges are checked, so a jump to the very bottom (which
		 * scrolls past the row) still counts as "visible".
		 */
		isSentinelVisible: function ()
		{
			if (!this.sentinel || !this.scroll)
			{
				return false;
			}

			var rootRect = this.scroll.getBoundingClientRect(),
				sentinelRect = this.sentinel.getBoundingClientRect(),
				margin = this.options.rootMargin;

			return sentinelRect.top <= rootRect.bottom + margin
				&& sentinelRect.bottom >= rootRect.top - margin;
		},

		/**
		 * Single decision point for "should the next page be requested now".
		 * Safe to call at any time: it does nothing while a load is running
		 * (requestMore remembers it), when paging stopped or after a failure.
		 */
		checkSentinel: function ()
		{
			if (!this.loaded || this.failed || !this.hasMore)
			{
				return;
			}

			if (this.isSentinelVisible())
			{
				this.requestMore();
			}
		},

		loadMore: function ()
		{
			if (this.loading || this.failed || !this.hasMore)
			{
				return;
			}

			this.loading = true;
			this.pendingMore = false;
			this.showLoading(true);

			var self = this,
				page = this.nextPage;

			XF.ajax('get', this.href, this.pageParams(page), null, this.ajaxOptions())
				.then(function (result)
				{
					if (!self.readReply(result))
					{
						return;
					}

					XF.setupHtmlInsert(result.data.html, function (html, container, onComplete)
					{
						return self.appendPage(html, page, onComplete);
					});
				}, function ()
				{
					self.showError();
				})
				.then(function ()
				{
					self.loading = false;
					self.showLoading(false);

					// The appended rows shift the sentinel down, but it often stays
					// inside the viewport (tall panel): neither the observer nor a
					// scroll event will fire. Re-check after the browser laid the
					// new rows out, so paging continues without user input.
					window.requestAnimationFrame(function ()
					{
						if (self.pendingMore || self.isSentinelVisible())
						{
							self.requestMore();
						}
					});
				});
		},

		/**
		 * The next-page fragment is also a full scroll container.
		 * Move its list rows into the existing list, then drop the wrapper.
		 *
		 * Rows are inserted into the live panel, so the stock handlers are
		 * activated on the list again (onComplete(false, list)) to keep
		 * tooltips / preview tooltips working on the appended items.
		 */
		appendPage: function (html, page, onComplete)
		{
			if (!html)
			{
				this.showError();
				return false;
			}

			var container = html.matches(this.options.scrollSelector)
				? html
				: html.querySelector(this.options.scrollSelector);
			if (!container)
			{
				this.showError();
				return false;
			}

			var newItems = container.querySelectorAll(this.options.itemSelector);
			for (var i = 0; i < newItems.length; i++)
			{
				this.list.appendChild(newItems[i]);
			}

			if (typeof onComplete === 'function')
			{
				onComplete(false, this.list);
			}

			this.readState(container);
			this.showLoading(false);

			if (this.thumb)
			{
				this.updateThumb();
			}

			if (!this.hasMore)
			{
				this.stopPaging();
			}

			return false;
		},

		/**
		 * Re-check after the first page settled. The sentinel may already be
		 * visible (tall panel): nothing would trigger the next request otherwise.
		 */
		loadAgainIfVisible: function ()
		{
			this.checkSentinel();
		},

		stopPaging: function ()
		{
			this.hasMore = false;

			if (this.sentinel)
			{
				this.sentinel.classList.remove('is-loading');

				// Nothing more to load: drop the reserved sentinel row so the list
				// does not end with an empty strip (see .ad90CtvSentinel.is-done).
				this.sentinel.classList.add('is-done');
			}

			if (this.observer)
			{
				this.observer.disconnect();
				this.observer = null;
			}
		},

		showLoading: function (show)
		{
			if (this.sentinel)
			{
				this.sentinel.classList.toggle('is-loading', show);
			}
		},

		/**
		 * A failed load must be visible to the user, not silently swallowed.
		 * Shows the server-side phrase from data-error-text and stops paging, so a
		 * broken endpoint cannot turn into an endless request loop.
		 */
		showError: function ()
		{
			this.showLoading(false);
			this.hasMore = false;
			this.failed = true;

			if (this.observer)
			{
				this.observer.disconnect();
				this.observer = null;
			}

			var text = this.menu.dataset.errorText || '';

			if (this.sentinel)
			{
				this.sentinel.innerHTML = text;
				this.sentinel.classList.add('is-error');
			}
			else if (!this.loaded)
			{
				// First page failed: the panel still holds the placeholder spinner.
				// It was kept closed until now (there was nothing to show yet), so
				// open it here — otherwise the failure would be invisible.
				this.menu.innerHTML = '';
				var row = document.createElement('div');
				row.className = 'ad90CtvSentinel is-error';
				row.textContent = text;
				this.menu.appendChild(row);

				this.open();
			}

			// Surface it for debugging too, instead of swallowing.
			if (window.console && console.warn)
			{
				console.warn('AD90 CustomThreadView: list load failed');
			}
		},

		/* ---- custom vertical thumb ---- */
		/**
		 * The native scrollbar is hidden by CSS (see .ad90CtvScroll). The panel
		 * still scrolls natively (wheel / touch / infinite-scroll); this draws an
		 * overlaid thumb over it, like the Recentpages scroller. Re-attaching on
		 * every attachPanel is safe: the old scroll element is discarded with the
		 * previous panel, so its listeners go with it.
		 */
		initThumb: function ()
		{
			var wrap = this.scroll.parentNode;
			this.thumb = wrap ? wrap.querySelector('.ad90Ctv-thumb') : null;

			XF.on(this.scroll, 'scroll.ad90CtvThumb', this.onThumbScroll.bind(this), { passive: true });

			if (this.thumb)
			{
				XF.on(this.thumb, 'pointerdown.ad90CtvThumb', this.onThumbDown.bind(this));
				XF.on(this.thumb, 'pointermove.ad90CtvThumb', this.onThumbMove.bind(this));
				XF.on(this.thumb, 'pointerup.ad90CtvThumb', this.endThumbDrag.bind(this));
				XF.on(this.thumb, 'pointercancel.ad90CtvThumb', this.endThumbDrag.bind(this));
			}

			if (window.ResizeObserver)
			{
				try
				{
					this.thumbResizeObserver = new ResizeObserver(this.updateThumb.bind(this));
					this.thumbResizeObserver.observe(this.scroll);
					if (this.list)
					{
						this.thumbResizeObserver.observe(this.list);
					}
				}
				catch (e)
				{
				}
			}

			this.updateThumb();
		},

		onThumbScroll: function ()
		{
			this.updateThumb();

			if (!this.thumb)
			{
				return;
			}

			var self = this;
			this.thumb.classList.add('is-scrolling');
			window.clearTimeout(this.thumbTimer);
			this.thumbTimer = window.setTimeout(function ()
			{
				self.thumb.classList.remove('is-scrolling');
			}, 700);
		},

		thumbMetrics: function ()
		{
			var sh = this.scroll.scrollHeight,
				ch = this.scroll.clientHeight,
				// The proportional height is capped from below at roughly half of the
				// panel height, so a long list (many loaded pages) never shrinks the
				// thumb to a stub. 32px stays as a floor for very short panels.
				h = Math.max(32, ch * 0.48, ch * ch / sh);
			return { sh: sh, ch: ch, h: h, track: ch - h, max: sh - ch };
		},

		updateThumb: function ()
		{
			if (!this.thumb)
			{
				return;
			}

			var m = this.thumbMetrics();
			if (m.max <= 1)
			{
				this.thumb.style.display = 'none';
				return;
			}

			this.thumb.style.display = 'block';
			this.thumb.style.height = m.h + 'px';
			this.thumb.style.transform = 'translateY(' + (this.scroll.scrollTop / m.max * m.track) + 'px)';
		},

		onThumbDown: function (e)
		{
			e.preventDefault();
			this.drag = { y: e.clientY, top: this.scroll.scrollTop };
			this.thumb.classList.add('is-drag');
			try { this.thumb.setPointerCapture(e.pointerId); } catch (err) {}
		},

		onThumbMove: function (e)
		{
			if (!this.drag)
			{
				return;
			}

			var m = this.thumbMetrics();
			if (m.track <= 0)
			{
				return;
			}

			this.scroll.scrollTop = this.drag.top + (e.clientY - this.drag.y) * m.max / m.track;
		},

		endThumbDrag: function ()
		{
			this.drag = null;
			if (this.thumb)
			{
				this.thumb.classList.remove('is-drag');
			}
		},

		/* ---- header offset ---- */
		updateOffset: function ()
		{
			var self = this;

			if (this._offsetRaf)
			{
				return;
			}

			this._offsetRaf = window.requestAnimationFrame(function ()
			{
				self._offsetRaf = null;

				// Stock header first, then the [AD90] CustomNavMenu header. The
				// custom one keeps .p-navSticky on its wrapper, but without the
				// --primary modifier, and its <header> is .ad90-nav (no .p-nav).
				var header = document.querySelector('.p-navSticky--primary')
					|| document.querySelector('.p-nav')
					|| document.querySelector('.ad90-nav')
					|| document.querySelector('.ad90-header-slot')
					|| document.querySelector('.p-header');

				var top = 0;
				if (header)
				{
					top = Math.max(0, Math.round(header.getBoundingClientRect().bottom));
				}

				self.menu.style.setProperty('--ad90-ctv-top', top + 'px');
			});
		}
	});

	XF.Element.register('ad90-ctv-menu', 'XF.Ad90CtvMenu');
}(window, document);
