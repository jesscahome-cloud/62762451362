<?php

namespace AD90\Recentpages\XF\Pub\Controller;

use XF\Entity\User;

/**
 * Расширение Account нужно только чтобы сохранить настройку ad90_show_recent_pages
 * на странице /account/preferences. Все операции с историей вынесены в
 * собственный контроллер AD90\Recentpages\Pub\Controller\RecentPage.
 */
class Account extends XFCP_Account
{
	protected function preferencesSaveProcess(User $visitor)
	{
		$form = parent::preferencesSaveProcess($visitor);

		if ($visitor->hasPermission('ad90RecentPages', 'view'))
		{
			$optionInput = $this->filter('option', 'array');
			$show = !empty($optionInput['ad90_show_recent_pages']);

			// Сохраняем через сущность UserOption штатным способом — поле
			// добавляется к той же Option, которую сохраняет родитель, и уходит
			// в той же транзакции formAction().
			$option = $visitor->getRelationOrDefault('Option');
			$form->setupEntityInput($option, ['ad90_show_recent_pages' => $show]);
		}

		return $form;
	}
}
