<?php

namespace AD90\Recentpages\Cron;

use AD90\Recentpages\Repository\RecentPage as RecentPageRepo;

/**
 * Ночная уборка истории недавних страниц.
 *
 * Закреплённые записи не удаляются никогда: это осознанный выбор пользователя.
 * Незакреплённые старше AD90_CLEANUP_DAYS удаляются — таблица не должна расти
 * бесконечно у неактивных пользователей.
 */
class CleanUp
{
	/** Сколько дней незакреплённая запись считается актуальной. */
	const RETENTION_DAYS = 90;

	public static function run()
	{
		/** @var RecentPageRepo $repo */
		$repo = \XF::app()->repository('AD90\Recentpages:RecentPage');

		$cutoff = \XF::$time - self::RETENTION_DAYS * 86400;
		$deleted = $repo->deleteOlderThan($cutoff);
	}
}
