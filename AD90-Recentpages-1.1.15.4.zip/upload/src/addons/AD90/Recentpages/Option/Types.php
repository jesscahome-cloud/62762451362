<?php

namespace AD90\Recentpages\Option;

use AD90\Recentpages\Provider\ProviderInterface;
use AD90\Recentpages\Provider\Registry;
use XF\Entity\Option;

/**
 * Значение опции ad90_types (edit_format="template").
 *
 * Хранится как массив «ключ типа → 1/0». Форма чекбоксов не отправляет снятые
 * галочки, поэтому отсутствие ключа означает «выключено» — здесь же оно
 * превращается в явный 0, чтобы значение опции было полным и читаемым.
 * Ключи, которых больше нет среди провайдеров (аддон удалён), сохраняются как
 * есть: они никому не мешают и вернутся, если аддон установят снова.
 */
class Types
{
	/**
	 * Список провайдеров: встроенные плюс добавленные через код-событие.
	 *
	 * @return ProviderInterface[]
	 */
	public static function providers(): array
	{
		$providers = Registry::all();
		\XF::app()->fire('ad90_recentpages_collect', [&$providers]);

		$out = [];
		foreach ($providers AS $provider)
		{
			if ($provider instanceof ProviderInterface)
			{
				$out[$provider->getType()] = $provider;
			}
		}

		return $out;
	}

	/**
	 * Чекбоксы опции: тип, название и текущее состояние.
	 *
	 * Тип без ключа в сохранённом значении — новый, он считается включённым.
	 *
	 * @param array $optionValue Текущее значение опции.
	 * @return array<int, array{type: string, title: string, selected: bool}>
	 */
	public static function choices($optionValue): array
	{
		$optionValue = is_array($optionValue) ? $optionValue : [];

		$choices = [];
		foreach (self::providers() AS $type => $provider)
		{
			$choices[] = [
				'type' => (string) $type,
				'title' => (string) \XF::phrase($provider->getTitlePhrase()),
				'selected' => array_key_exists($type, $optionValue) ? !empty($optionValue[$type]) : true,
			];
		}

		return $choices;
	}

	/**
	 * Нормализует сохраняемое значение: все известные типы получают явные 1/0.
	 *
	 * @param array  $value
	 * @param Option $option
	 * @return bool
	 */
	public static function verify(&$value, Option $option)
	{
		if (!is_array($value))
		{
			$value = [];
		}

		$normalized = [];
		foreach (self::providers() AS $type => $provider)
		{
			$normalized[$type] = !empty($value[$type]) ? 1 : 0;
		}

		// Ключи удалённых аддонов сохраняем: они не мешают и вернутся вместе с аддоном.
		foreach ($value AS $type => $on)
		{
			if (!isset($normalized[$type]))
			{
				$normalized[$type] = !empty($on) ? 1 : 0;
			}
		}

		$value = $normalized;

		return true;
	}

	/**
	 * Функция шаблонов ad90_recentpages_type_choices(): чекбоксы для шаблона опции.
	 *
	 * @param \XF\Template\Templater $templater
	 * @param bool                   $escape
	 * @param array                  $optionValue
	 * @return array
	 */
	public static function fnChoices($templater, &$escape, $optionValue = [])
	{
		$escape = false;

		return self::choices($optionValue);
	}
}
