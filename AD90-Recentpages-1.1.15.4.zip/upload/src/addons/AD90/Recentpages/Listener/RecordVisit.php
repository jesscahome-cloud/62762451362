<?php

namespace AD90\Recentpages\Listener;

use AD90\Recentpages\Limits;
use AD90\Recentpages\Provider\ProviderInterface;
use AD90\Recentpages\Provider\Registry;
use XF\Mvc\Controller;
use XF\Mvc\ParameterBag;
use XF\Mvc\Reply\AbstractReply;
use XF\Mvc\Reply\View;

/**
 * Слушатель controller_post_dispatch: определяет, что показанная страница —
 * контент из белого списка типов, и откладывает запись визита на конец того же
 * запроса (XF::runLater). Никакого отдельного POST из браузера не нужно.
 *
 * Что запоминать решается по типу ответа контроллера (Reply\View + viewClass),
 * а не по URL. Список типов расширяется код-событием ad90_recentpages_collect.
 */
class RecordVisit
{
	public static function controllerPostDispatch(
		Controller $controller,
		$action,
		ParameterBag $params,
		AbstractReply &$reply
	): void {
		// Только полноценные HTML-страницы, не AJAX, HEAD, предзагрузка и боты.
		if (!$reply instanceof View)
		{
			return;
		}

		$request = \XF::app()->request();
		if ($request->isXhr() || $request->isHead() || $request->isPrefetch())
		{
			return;
		}

		// Бот не залогинен и отсекается проверкой user_id ниже.
		$visitor = \XF::visitor();
		if (!$visitor->user_id || !$visitor->hasPermission('ad90RecentPages', 'view'))
		{
			return;
		}

		// Пользователь скрыл блок — не пишем в пустоту.
		if (!$visitor->Option->ad90_show_recent_pages)
		{
			return;
		}

		$viewClass = $reply->getViewClass();
		if (!$viewClass)
		{
			return;
		}

		$providers = Registry::all();

		// Позволяем сторонним аддонам добавить свои типы страниц.
		\XF::app()->fire('ad90_recentpages_collect', [&$providers, $controller, $action, $params, $reply]);

		$matched = null;
		foreach ($providers AS $provider)
		{
			if (!$provider instanceof ProviderInterface)
			{
				continue;
			}

			if (!Limits::isTypeEnabled($provider->getType()))
			{
				continue;
			}

			$matched = $provider->match($viewClass, $reply);
			if ($matched !== null)
			{
				$matched['type'] = $provider->getType();
				break;
			}
		}

		if ($matched === null)
		{
			return;
		}

		$userId = (int) $visitor->user_id;
		$max = Limits::maxItems($visitor);
		if ($max <= 0)
		{
			return;
		}

		$record = [
			'type' => $matched['type'],
			'title' => $matched['title'],
			'url' => $matched['url'],
			'params' => $matched['params'] ?? [],
		];

		// Пишем после формирования ответа, чтобы не тормозить отдачу страницы.
		\XF::runLater(function () use ($userId, $max, $record)
		{
			$repo = \XF::app()->repository('AD90\Recentpages:RecentPage');
			$repo->recordVisit(
				$userId,
				$record['url'],
				$record['type'],
				$record['title'],
				$record['params'],
				$max
			);
		});
	}

	/**
	 * user_delete_clean_init: регистрирует удаление истории вместе с удалением
	 * пользователя. Таблица не является content type, поэтому XF сам её не
	 * чистит — добавляем запрос в список штатной очистки.
	 *
	 * @param \XF\Service\User\DeleteCleanUp $deleteService
	 * @param array $deletes
	 */
	public static function userDeleteCleanInit($deleteService, array &$deletes): void
	{
		$deletes['xf_ad90_recentpages_page'] = 'user_id = ?';
	}
}
