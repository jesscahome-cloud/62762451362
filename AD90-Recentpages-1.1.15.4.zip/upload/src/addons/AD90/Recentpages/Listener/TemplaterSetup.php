<?php

namespace AD90\Recentpages\Listener;

use AD90\Recentpages\Option\Types;
use XF\Container;
use XF\Template\Templater;

/**
 * Регистрация функций шаблонов аддона.
 *
 * ad90_recentpages_type_choices() отдаёт чекбоксы опции ad90_types: список типов
 * строится из провайдеров, включая добавленные сторонними аддонами через
 * код-событие ad90_recentpages_collect. Так тип из чужого аддона тоже попадает
 * в опцию и его можно отключить.
 */
class TemplaterSetup
{
	public static function templaterSetup(Container $container, Templater &$templater)
	{
		$templater->addFunction('ad90_recentpages_type_choices', [Types::class, 'fnChoices']);
	}
}
