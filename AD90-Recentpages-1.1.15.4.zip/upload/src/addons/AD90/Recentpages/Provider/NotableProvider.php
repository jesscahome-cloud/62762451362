<?php

namespace AD90\Recentpages\Provider;

use XF\Mvc\Reply\View;

/**
 * Провайдер страницы «Полезные пользователи» (/members/).
 *
 * Это не сущность, а сводный список участников, поэтому заголовок берётся не из
 * поля сущности: при открытой подборке — название подборки (member stat), иначе
 * штатная фраза notable_members. URL всегда один — корень списка участников,
 * поэтому повторные заходы обновляют одну запись, а не плодят дубли.
 */
class NotableProvider extends BuiltinProvider
{
	public function match(string $viewClass, View $reply): ?array
	{
		if (!in_array($viewClass, $this->viewClasses, true))
		{
			return null;
		}

		$params = $reply->getParams();

		$title = '';
		$active = $params['active'] ?? null;
		if ($active instanceof \XF\Entity\MemberStat)
		{
			$title = (string) $active->title;
		}
		if (trim($title) === '')
		{
			$title = (string) \XF::phrase('notable_members');
		}

		$url = \XF::app()->router('public')->buildLink($this->route);

		return [
			'title' => $title,
			'url' => $url,
			'params' => [],
		];
	}
}
